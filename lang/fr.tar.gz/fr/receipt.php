<?php

 return [
     'product' => 'Produit',
     'qty' => 'Quantité',
     'unit_price' => 'Prix unitaire',
     'subtotal' => 'Total',
     'discount' => 'Remise',
     'tax' => 'Impôt',
     'total' => 'Total',
     'invoice_number' => 'Facture no.',
     'date' => 'Date',
     'receipt_settings' => 'Paramètres de reçu',
     'receipt_settings_mgs' => 'Tous les paramètres liés au reçu pour cet emplacement',
     'print_receipt_on_invoice' => 'Impression automatique de la facture après la finalisation',
     'receipt_printer_type' => "Type d'imprimante de reçu",
     'receipt_settings_updated' => 'Paramètre de reçu mis à jour avec succès',
 ];
