@extends('layouts.app')

@section('content')
@include('hms::layouts.nav')

@endsection
