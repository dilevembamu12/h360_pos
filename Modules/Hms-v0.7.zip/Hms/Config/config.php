<?php

return [
    'name' => 'Hms',
    'module_version' => '0.7',
    'pid' => '18',
];
