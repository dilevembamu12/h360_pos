<?php

use Illuminate\Support\Facades\Route;
use Modules\Hopital\Http\Controllers\PatientController;
use Modules\Hopital\Http\Controllers\AppointmentController;
use Modules\Hopital\Http\Controllers\StaffController;
use Modules\Hopital\Http\Controllers\BillingController;
use Modules\Hopital\Http\Controllers\InpatientController;
use Modules\Hopital\Http\Controllers\EmergencyController;
use Modules\Hopital\Http\Controllers\LabController;
use Modules\Hopital\Http\Controllers\BedController;
use Modules\Hopital\Http\Controllers\StaffScheduleController;

// Assurez-vous d'importer tous les contrôleurs nécessaires

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Exemple de route principale pour le module Hôpital (peut-être un dashboard ou une page d'accueil)
Route::group(['prefix' => 'hopital', 'middleware' => 'web'], function() {

    // Dashboard / Accueil du module (peut-être une page d'accueil personnalisée ou un résumé)
    Route::get('/', 'Modules\Hopital\Http\Controllers\HopitalController@index')->name('hopital.dashboard');

    // Gestion des Patients
    Route::resource('patients', PatientController::class); // CRUD pour les patients
    Route::get('patients/{patient}/medical-history', [PatientController::class, 'showMedicalHistory'])->name('hopital.patients.medical_history'); // Afficher historique médical
    //Route::get('/patients', 'Modules\Hopital\Http\Controllers\InpatientController@index')->name('hopital.inpatients.index');
    //Route::get('/patients', 'Modules\Hopital\Http\Controllers\InpatientController@index')->name('hopital.inpatients.index');
    

    // Gestion des Rendez-vous / Consultations
    Route::resource('appointments', AppointmentController::class); // CRUD pour les rendez-vous

    // Gestion du Personnel Médical
    Route::resource('staff', StaffController::class); // CRUD pour le personnel
    Route::resource('staff-schedules', StaffScheduleController::class); // CRUD pour les plannings

    // Gestion Financière / Facturation
    Route::resource('billing', BillingController::class); // CRUD pour la facturation (factures, items)
    // Potentiellement des routes spécifiques pour les paiements, assurances, etc.
    Route::resource('insurance-claims', InsuranceClaimController::class); // CRUD pour les demandes assurance

    // Laboratoire et Examens
    Route::get('lab/orders', [LabController::class, 'listOrders'])->name('hopital.lab.orders'); // Lister les commandes d'examens
    Route::get('lab/results', [LabController::class, 'listResults'])->name('hopital.lab.results'); // Lister les résultats
    Route::get('lab/orders/{order}/results', [LabController::class, 'showResultsForOrder'])->name('hopital.lab.orders.results'); // Afficher les résultats pour une commande
    Route::post('lab/orders/{order}/upload-results', [LabController::class, 'uploadResults'])->name('hopital.lab.orders.upload_results'); // Uploader les résultats

    // Gestion des Lits et Patients Hospitalisés
    Route::resource('beds', BedController::class); // Gestion des lits et chambres
    Route::resource('inpatients', InpatientController::class); // Gestion des hospitalisations (admission, sortie, suivi)
    //Route::get('inpatients', [InpatientController::class, 'index'])->name('hopital.inpatients.index'); // Lister les commandes d'examens
    Route::get('/inpatients',  [InpatientController::class, 'index'])->name('hopital.inpatients.index');
    
    // Gestion des Urgences
    Route::get('emergencies', [EmergencyController::class, 'index'])->name('hopital.emergencies.index'); // Liste des urgences
    Route::get('emergencies/{emergency}', [EmergencyController::class, 'show'])->name('hopital.emergencies.show'); // Détail d'une urgence
    Route::post('emergencies/alert', [EmergencyController::class, 'createAlert'])->name('hopital.emergencies.create_alert'); // Déclencher une alerte

    // Ajoutez d'autres routes ici selon les besoins spécifiques

});