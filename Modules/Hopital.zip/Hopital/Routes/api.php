<?php

use Illuminate\Support\Facades\Route;
use Modules\Hopital\Http\Controllers\Api\PatientApiController;
use Modules\Hopital\Http\Controllers\Api\AppointmentApiController;
use Modules\Hopital\Http\Controllers\Api\StaffApiController;
use Modules\Hopital\Http\Controllers\Api\BillingApiController;
use Modules\Hopital\Http\Controllers\Api\InpatientApiController;
use Modules\Hopital\Http\Controllers\Api\EmergencyApiController;
use Modules\Hopital\Http\Controllers\Api\LabApiController;
use Modules\Hopital\Http\Controllers\Api\BedApiController;
use Modules\Hopital\Http\Controllers\Api\StaffScheduleApiController;
// Assurez-vous d'importer les contrôleurs API nécessaires
// Notez que j'ai suggéré d'utiliser un sous-dossier 'Api' dans les contrôleurs pour les distinguer

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['prefix' => 'hopital', 'middleware' => 'api'], function() {

    // API pour la gestion des Patients
    Route::apiResource('patients', PatientApiController::class);
    Route::get('patients/{patient}/medical-history', [PatientApiController::class, 'getMedicalHistory']);
    Route::post('patients/{patient}/medical-history', [PatientApiController::class, 'addMedicalHistoryEntry']);
    // Ajoutez des routes spécifiques pour les allergies, médicaments actuels, etc.

    // API pour la gestion des Rendez-vous
    Route::apiResource('appointments', AppointmentApiController::class);

    // API pour la gestion du Personnel
    Route::apiResource('staff', StaffApiController::class);
    Route::apiResource('staff-schedules', StaffScheduleApiController::class);

    // API pour la gestion Financière
    Route::apiResource('billing', BillingApiController::class); // API pour les factures
    Route::apiResource('insurance-claims', InsuranceClaimApiController::class); // API pour les demandes assurance

    // API pour le Laboratoire et Examens
    Route::get('lab/orders', [LabApiController::class, 'listOrders']);
    Route::get('lab/orders/{order}', [LabApiController::class, 'showOrder']);
    Route::post('lab/orders', [LabApiController::class, 'createOrder']);
    Route::get('lab/orders/{order}/results', [LabApiController::class, 'getResultsForOrder']);
    Route::post('lab/orders/{order}/upload-results', [LabApiController::class, 'uploadResults']);

    // API pour la gestion des Lits et Patients Hospitalisés
    Route::apiResource('beds', BedApiController::class);
    Route::apiResource('inpatients', InpatientApiController::class);

    // API pour la gestion des Urgences
    Route::get('emergencies', [EmergencyApiController::class, 'index']);
    Route::post('emergencies/alert', [EmergencyApiController::class, 'createAlert']);
    Route::get('emergencies/{emergency}', [EmergencyApiController::class, 'show']);
    // Potentiellement des routes pour mettre à jour le statut de l'urgence, etc.

    // Ajoutez d'autres routes API selon les besoins

});