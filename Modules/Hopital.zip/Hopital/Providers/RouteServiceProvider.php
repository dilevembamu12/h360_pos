<?php

namespace Modules\Hopital\Providers;

use Illuminate\Support\Facades\Route;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * Le namespace des contrôleurs du module.
     *
     * Dans les modules Nwidart, les contrôleurs sont généralement dans
     * Http/Controllers. Les contrôleurs API sont dans Http/Controllers/Api.
     */
    protected $moduleNamespace = 'Modules\Hopital\Http\Controllers';

    /**
     * Démarrez le processus de mappage des routes.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();
    }

    /**
     * Définissez les mappings de routes pour le module.
     *
     * Dans la plupart des cas, sans état, vos mappages de routes sont définis ici.
     * La méthode "map" fournit simplement une façon pratique de charger
     * vos points d'entrée de routes web et API pour votre module.
     *
     * @return void
     */
    public function map()
    {
        $this->mapApiRoutes();

        $this->mapWebRoutes();
    }

    /**
     * Définissez les routes API pour le module.
     *
     * Ces routes sont sans état, à travers le groupe de middleware "api".
     *
     * @return void
     */
    protected function mapApiRoutes()
    {
        Route::prefix('api') // Ajoute le préfixe /api à toutes les routes définies ici
             ->middleware('api') // Applique le middleware 'api' (sessions, etc.)
             ->namespace($this->moduleNamespace . '\Api') // Définit le namespace pour les contrôleurs API (Modules\Hopital\Http\Controllers\Api)
             ->group(module_path('Hopital', '/Routes/api.php')); // Charge le fichier de routes API du module
    }

    /**
     * Définissez les routes web pour le module.
     *
     * Ces routes ont un état, utilisent la session et le groupe de middleware "web".
     *
     * @return void
     */
    protected function mapWebRoutes()
    {
        Route::middleware('web') // Applique le middleware 'web' (sessions, CSRF, etc.)
             ->namespace($this->moduleNamespace) // Définit le namespace par défaut pour les contrôleurs web (Modules\Hopital\Http\Controllers)
             ->group(module_path('Hopital', '/Routes/web.php')); // Charge le fichier de routes web du module
    }
}