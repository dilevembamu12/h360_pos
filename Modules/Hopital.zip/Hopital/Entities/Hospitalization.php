<?php
// Modules/Hopital/Entities/Hospitalization.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class Hospitalization extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_hospitalizations'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'patient_id',
        'bed_id',
        'admission_date',
        'discharge_date', // Peut être nulle si toujours hospitalisé
        'status', // e.g., 'Active', 'Discharged', 'Planned', 'Cancelled'
        'reason_for_admission',
        'diagnosis', // Diagnostic à l'admission (nullable)
        'notes', // Instructions, suivi
        // Ajoutez d'autres champs pertinents comme le médecin traitant principal, le département
    ];

    protected $dates = ['admission_date', 'discharge_date'];

    // Relation avec le patient
    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    // Relation avec le lit attribué
    public function bed()
    {
        return $this->belongsTo(Bed::class);
    }

    // Relation avec les factures générées pour cette hospitalisation
    public function bills()
    {
        return $this->hasMany(Bill::class);
    }

    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\HospitalizationFactory::new();
    }
}