<?php
// Modules/Hopital/Entities/Appointment.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Appointment extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_appointments'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'patient_id',
        'staff_id', // Le médecin ou professionnel de santé
        'date_time',
        'type', // e.g., 'Consultation', 'Examen', 'Suivi'
        'status', // e.g., 'Scheduled', 'Completed', 'Cancelled', 'No Show'
        'reason', // Raison du rendez-vous
        'notes', // Notes additionnelles
        // Ajoutez d'autres champs pertinents comme la durée
    ];

    protected $dates = ['date_time']; // Caster la colonne en instance Carbon

    // Relation avec le patient
    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    // Relation avec le membre du personnel (médecin, etc.)
    public function staff()
    {
        return $this->belongsTo(Staff::class);
    }

    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\AppointmentFactory::new();
    }
}