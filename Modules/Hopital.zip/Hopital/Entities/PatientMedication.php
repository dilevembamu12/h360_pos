<?php
// Modules/Hopital/Entities/PatientMedication.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PatientMedication extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_patient_medications'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'patient_id',
        'medication_name', // Nom du médicament
        'dosage', // Posologie (ex: 500mg)
        'frequency', // Fréquence (ex: 3 fois par jour)
        'route', // Voie d'administration (ex: orale, IV)
        'start_date',
        'end_date', // Date de fin prévue (peut être nulle si traitement continu)
        'prescriber_staff_id', // Qui a prescrit (clé étrangère vers le modèle Staff)
        'notes', // Instructions spéciales, raison de la prise
        // Ajoutez d'autres champs pertinents
    ];

    // Relation avec le patient
    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    // Relation avec le membre du personnel qui a prescrit
    public function prescriber()
    {
        return $this->belongsTo(Staff::class, 'prescriber_staff_id');
    }

    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\PatientMedicationFactory::new();
    }
}