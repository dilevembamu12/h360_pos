<?php
// Modules/Hopital/Entities/Room.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class Room extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_rooms'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'room_number',
        'type', // e.g., 'Standard', 'Private', 'Suite'
        'capacity', // Nombre de lits
        'department_id', // Le département auquel la chambre appartient (si pertinent)
        'notes', // Équipements spéciaux
        // Ajoutez d'autres champs pertinents
    ];

    // Relation avec les lits dans cette chambre
    public function beds()
    {
        return $this->hasMany(Bed::class);
    }

    // Relation avec le département (si un modèle Department existe)
    // public function department()
    // {
    //     return $this->belongsTo(Department::class);
    // }


    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\RoomFactory::new();
    }
}