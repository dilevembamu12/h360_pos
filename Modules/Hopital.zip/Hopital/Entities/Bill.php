<?php
// Modules/Hopital/Entities/Bill.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Bill extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_bills'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'patient_id',
        'hospitalization_id', // Si la facture est liée à une hospitalisation (nullable)
        'bill_date',
        'due_date',
        'total_amount',
        'paid_amount',
        'balance_amount', // total - paid
        'status', // e.g., 'Pending', 'Paid', 'Partially Paid', 'Cancelled', 'Submitted to Insurance'
        'notes', // Références, etc.
        // Ajoutez des champs pour la méthode de paiement, etc.
    ];

    protected $dates = ['bill_date', 'due_date'];

    // Relation avec le patient
    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    // Relation avec l'hospitalisation (si applicable)
    public function hospitalization()
    {
        return $this->belongsTo(Hospitalization::class);
    }

    // Relation avec les lignes de facture
    public function items()
    {
        return $this->hasMany(BillItem::class);
    }

    // Relation avec les demandes d'indemnisation assurance liées
    public function insuranceClaims()
    {
        return $this->hasMany(InsuranceClaim::class);
    }


    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\BillFactory::new();
    }
}