<?php
// Modules/Hopital/Entities/Patient.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes; // Pour la gestion des patients inactifs plutôt que supprimés

class Patient extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_patients'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'first_name',
        'last_name',
        'date_of_birth',
        'gender', // e.g., 'M', 'F', 'Other'
        'contact_number',
        'email',
        'address',
        'patient_type', // e.g., 'Ambulatoire', 'Hospitalisé'
        // Ajoutez d'autres champs pertinents comme le numéro de sécurité sociale, etc.
    ];

    // Relation avec l'historique médical
    public function medicalHistory()
    {
        return $this->hasMany(PatientMedicalHistory::class);
    }

    // Relation avec les allergies
    public function allergies()
    {
        return $this->hasMany(PatientAllergy::class);
    }

    // Relation avec les médicaments actuels
    public function currentMedications()
    {
        return $this->hasMany(PatientMedication::class);
    }

    // Relation avec les rendez-vous/consultations
    public function appointments()
    {
        return $this->hasMany(Appointment::class);
    }

    // Relation avec les hospitalisations
    public function hospitalizations()
    {
        return $this->hasMany(Hospitalization::class);
    }

    // Relation avec les factures
    public function bills()
    {
        return $this->hasMany(Bill::class);
    }

    // Relation avec les examens commandés
    public function examOrders()
    {
        return $this->hasMany(ExamOrder::class);
    }

    // Relation avec les urgences (si le patient est identifié)
    public function emergencies()
    {
        return $this->hasMany(Emergency::class);
    }

    protected static function newFactory()
    {
        // Vous pouvez créer une factory pour ce modèle si nécessaire
        // return \Modules\Hopital\Database\Factories\PatientFactory::new();
    }
}