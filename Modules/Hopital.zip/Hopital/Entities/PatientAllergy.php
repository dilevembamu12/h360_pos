<?php
// Modules/Hopital/Entities/PatientAllergy.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PatientAllergy extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_patient_allergies'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'patient_id',
        'allergy_name', // Nom de l'allergène (ex: Penicilline, Pollen)
        'severity', // e.g., 'Mild', 'Moderate', 'Severe'
        'reaction_description', // Comment le patient réagit
        'notes', // Informations supplémentaires
        // Ajoutez d'autres champs pertinents
    ];

    // Relation avec le patient
    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\PatientAllergyFactory::new();
    }
}