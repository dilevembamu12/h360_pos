<?php
// Modules/Hopital/Entities/Bed.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class Bed extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_beds'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'room_id',
        'bed_number', // e.g., 'Chambre 101 - Lit A' ou simplement 'A' si room_id est parent
        'status', // e.g., 'Available', 'Occupied', 'Maintenance', 'Reserved'
        'notes', // Équipements spécifiques du lit
        // Ajoutez d'autres champs pertinents
    ];

    // Relation avec la chambre parente
    public function room()
    {
        return $this->belongsTo(Room::class);
    }

    // Relation avec l'hospitalisation actuelle sur ce lit (peut être nulle)
    public function currentHospitalization()
    {
        return $this->hasOne(Hospitalization::class)->whereNull('discharge_date');
    }

    // Relation avec toutes les hospitalisations qui ont eu lieu sur ce lit
    public function hospitalizations()
    {
        return $this->hasMany(Hospitalization::class);
    }


    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\BedFactory::new();
    }
}