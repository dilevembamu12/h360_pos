<?php
// Modules/Hopital/Entities/MedicalRecord.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

// Note : Ce modèle pourrait servir de point d'entrée générique
// pour différents types d'entrées dans le dossier médical (notes de consultation,
// résumé d'hospitalisation, etc.), ou vous pourriez gérer le dossier médical
// principalement via les relations directes des modèles Patient, Appointment, etc.
// Ici, c'est un exemple simple d'entrée/note dans le dossier.

class MedicalRecord extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    //protected $table = 'hopital_patient_medications'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'patient_id',
        'appointment_id', // Peut être lié à un rendez-vous spécifique (nullable)
        'staff_id', // Le professionnel de santé qui a créé l'entrée
        'record_date',
        'type', // e.g., 'Consultation Note', 'Progress Report', 'Summary'
        'content', // Le texte ou le contenu de l'entrée
        // Ajoutez d'autres champs pertinents
    ];

    protected $dates = ['record_date'];

    // Relation avec le patient
    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    // Relation avec le rendez-vous (si applicable)
    public function appointment()
    {
        return $this->belongsTo(Appointment::class);
    }

    // Relation avec le membre du personnel
    public function staff()
    {
        return $this->belongsTo(Staff::class);
    }


    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\MedicalRecordFactory::new();
    }
}