<?php
// Modules/Hopital/Entities/PatientMedicalHistory.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PatientMedicalHistory extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_patient_medical_histories'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'patient_id',
        'condition_name', // Nom de l'affection/condition
        'diagnosis_date',
        'notes', // Description, traitements passés, etc.
        // Ajoutez d'autres champs pertinents
    ];

    // Relation avec le patient
    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\PatientMedicalHistoryFactory::new();
    }
}