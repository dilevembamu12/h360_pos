<?php
// Modules/Hopital/Entities/Staff.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
// Important: Vous pourriez vouloir lier cela au modèle User de votre application principale.
// Pour l'instant, c'est un modèle séparé, mais pensez à l'intégration.
// use App\Models\User; // Exemple si vous liez au modèle User principal

class Staff extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_staff'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'user_id', // Clé étrangère vers le modèle User si utilisé
        'first_name',
        'last_name',
        'role', // e.g., 'Médecin', 'Infirmière', 'Administratif'
        'specialization', // e.g., 'Cardiologie', 'Pédiatrie' (nullable)
        'contact_number',
        'email',
        'address',
        // Ajoutez d'autres champs pertinents comme les identifiants professionnels
    ];

    // Si lié au modèle User principal
    // public function user()
    // {
    //     return $this->belongsTo(User::class);
    // }

    // Relation avec les rendez-vous où ce membre du personnel est impliqué
    public function appointments()
    {
        return $this->hasMany(Appointment::class);
    }

    // Relation avec les plannings de ce membre du personnel
    public function schedules()
    {
        return $this->hasMany(StaffSchedule::class);
    }

    // Relation avec les médicaments prescrits par ce membre du personnel
    public function prescribedMedications()
    {
        return $this->hasMany(PatientMedication::class, 'prescriber_staff_id');
    }

     // Relation avec les résultats de laboratoire validés/effectués par ce membre du personnel
     public function labResults()
     {
         return $this->hasMany(LabResult::class);
     }

    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\StaffFactory::new();
    }
}