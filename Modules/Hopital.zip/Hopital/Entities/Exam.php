<?php
// Modules/Hopital/Entities/Exam.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

// Ce modèle représente un *type* d'examen (ex: 'Radiographie', 'Analyse Sanguine Complète')
class Exam extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_exams'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'name', // Nom de l'examen
        'description',
        'code', // Code interne ou externe de l'examen
        'price', // Coût de l'examen (peut aussi être géré dans BillingItem)
        'requires_prescription', // Boolean
        // Ajoutez d'autres champs pertinents comme le département associé (Laboratoire, Radiologie)
    ];

    // Relation avec les commandes de cet type d'examen
    public function examOrders()
    {
        return $this->hasMany(ExamOrder::class);
    }


    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\ExamFactory::new();
    }
}