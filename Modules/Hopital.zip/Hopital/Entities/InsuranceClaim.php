<?php
// Modules/Hopital/Entities/InsuranceClaim.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class InsuranceClaim extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_insurance_claims'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'bill_id', // La facture soumise pour remboursement
        'insurance_company_name',
        'policy_number',
        'claim_date', // Date de soumission de la demande
        'status', // e.g., 'Submitted', 'Processing', 'Approved', 'Rejected', 'Paid', 'Partially Paid'
        'claimed_amount', // Montant initial réclamé
        'approved_amount', // Montant approuvé par l'assurance (nullable)
        'paid_amount', // Montant effectivement payé par l'assurance (nullable)
        'notes', // Communications avec l'assurance, raisons du rejet, etc.
        // Ajoutez des champs pour les documents joints
    ];

    protected $dates = ['claim_date'];

    // Relation avec la facture associée
    public function bill()
    {
        return $this->belongsTo(Bill::class);
    }


    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\InsuranceClaimFactory::new();
    }
}