<?php
// Modules/Hopital/Entities/StaffSchedule.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class StaffSchedule extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_staff_schedules'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'staff_id',
        'schedule_date',
        'start_time',
        'end_time',
        'location', // e.g., 'Département X', 'Bloc Y'
        'notes', // Congés, garde, etc.
        // Ajoutez d'autres champs pertinents
    ];

    protected $dates = ['schedule_date', 'start_time', 'end_time']; // Caster en instances Carbon

    // Relation avec le membre du personnel
    public function staff()
    {
        return $this->belongsTo(Staff::class);
    }

    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\StaffScheduleFactory::new();
    }
}