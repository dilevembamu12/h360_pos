<?php
// Modules/Hopital/Entities/LabResult.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class LabResult extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_lab_results'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'exam_order_id', // La commande d'examen associée
        'result_date',
        'staff_id', // Le personnel (technicien, biologiste) qui a validé/entré le résultat
        'details', // Les résultats de l'examen (peut être JSON pour structures complexes)
        'notes', // Interprétation ou remarques
        'is_abnormal', // Boolean pour indiquer si les résultats sont hors norme
        // Ajoutez des champs pour les fichiers de rapport si nécessaire
    ];

    protected $dates = ['result_date'];

    protected $casts = [
        'details' => 'json', // Utile si les résultats sont structurés
    ];

    // Relation avec la commande d'examen
    public function examOrder()
    {
        return $this->belongsTo(ExamOrder::class);
    }

    // Relation avec le personnel qui a traité le résultat
    public function staff()
    {
        return $this->belongsTo(Staff::class);
    }


    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\LabResultFactory::new();
    }
}