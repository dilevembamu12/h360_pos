<?php
// Modules/Hopital/Entities/Emergency.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Emergency extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_emergencies'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'patient_id', // Nullable si le patient n'est pas immédiatement identifié
        'type', // e.g., 'Cardiac Arrest', 'Trauma', 'Severe Allergy'
        'severity', // e.g., 'Code Red', 'Urgent', 'Semi-Urgent'
        'reported_at', // Timestamp de l'alerte
        'resolved_at', // Timestamp de résolution (nullable)
        'status', // e.g., 'Active', 'Resolved', 'Cancelled'
        'initial_observation', // Description initiale de la situation
        'notes', // Suivi de l'intervention, etc.
        // Ajoutez des champs pour le personnel appelé, l'emplacement de l'urgence
    ];

    protected $dates = ['reported_at', 'resolved_at'];

    // Relation avec le patient (nullable)
    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }


    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\EmergencyFactory::new();
    }
}