<?php
// Modules/Hopital/Entities/ExamOrder.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

// Ce modèle représente une *commande* spécifique d'examen pour un patient
class ExamOrder extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_exam_orders'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'patient_id',
        'staff_id', // Le médecin qui commande l'examen
        'exam_id', // Le type d'examen commandé
        'order_date',
        'status', // e.g., 'Ordered', 'Sample Collected', 'In Progress', 'Completed', 'Cancelled'
        'clinical_info', // Informations cliniques pertinentes pour l'examen
        'notes', // Instructions spéciales
        // Ajoutez d'autres champs pertinents comme l'urgence
    ];

    protected $dates = ['order_date'];

    // Relation avec le patient
    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    // Relation avec le membre du personnel (médecin)
    public function staff()
    {
        return $this->belongsTo(Staff::class);
    }

    // Relation avec le type d'examen
    public function exam()
    {
        return $this->belongsTo(Exam::class);
    }

    // Relation avec le résultat de cet examen (si complété)
    public function labResult()
    {
        return $this->hasOne(LabResult::class);
    }


    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\ExamOrderFactory::new();
    }
}