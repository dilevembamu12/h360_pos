<?php
// Modules/Hopital/Entities/BillItem.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class BillItem extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_bill_items'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'bill_id',
        'description', // Ex: 'Consultation Médecin Dupont', 'Radiographie Thoracique', 'Médicament Ibuprofène 500mg'
        'quantity',
        'unit_price',
        'total_price', // quantity * unit_price
        // Ajoutez des champs pour le code du service/produit, lien vers Appointment, ExamOrder, PatientMedication etc.
        'related_entity_type', // Ex: 'Appointment', 'ExamOrder'
        'related_entity_id',
    ];

    // Relation avec la facture parente
    public function bill()
    {
        return $this->belongsTo(Bill::class);
    }

    // Relation morphique pour lier à l'entité d'origine (Consultation, Examen, Médicament...)
    public function relatedEntity()
    {
        return $this->morphTo(__FUNCTION__, 'related_entity_type', 'related_entity_id');
    }


    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\BillItemFactory::new();
    }
}