<?php
// Modules/Hopital/Entities/Prescription.php

namespace Modules\Hopital\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Prescription extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'hopital_prescriptions'; // <-- Spécifiez le nom complet de la table ici

protected $fillable = [


        'patient_id',
        'staff_id', // Le médecin qui prescrit
        'prescription_date',
        'validity_period_days', // Durée de validité en jours (nullable)
        'notes', // Instructions générales, remarques
        // Considérez stocker les détails des médicaments ici, ou via une relation
        // 'medications' => ['medication_name' => ..., 'dosage' => ...] si JSON/texte
        // Ou mieux, lier à PatientMedication entries si c'est un suivi des médocs *actuels*
    ];

    protected $dates = ['prescription_date'];

    // Relation avec le patient
    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    // Relation avec le membre du personnel (médecin)
    public function staff()
    {
        return $this->belongsTo(Staff::class);
    }

    // Peut-être une relation avec les entrées de PatientMedication créées à partir de cette prescription
    public function patientMedications()
    {
         return $this->hasMany(PatientMedication::class, 'prescription_id'); // Nécessite d'ajouter prescription_id dans PatientMedication
    }


    protected static function newFactory()
    {
        // return \Modules\Hopital\Database\Factories\PrescriptionFactory::new();
    }
}