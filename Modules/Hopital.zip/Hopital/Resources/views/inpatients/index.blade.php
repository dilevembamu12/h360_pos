@extends('hopital::layouts.master')

@section('content')
    <h1>Gestion des Patients Hospitalisés</h1>

    <p>
        Ceci liste les patients actuellement hospitalisés.
    </p>

    <table>
        <thead>
            <tr>
                <th>Patient</th>
                <th>Chambre</th>
                <th>Lit</th>
                <th>Date d'Admission</th>
                <th>Médecin Traitant</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Jane DOE</td>
                <td>Chambre 101</td>
                <td>Lit A</td>
                <td>2023-10-25</td>
                <td>Dr. House</td>
                <td>
                    <a href="#">Voir Dossier</a> | <a href="#">Suivre Soins</a> | <a href="#">Planifier Sortie</a>
                </td>
            </tr>
        </tbody>
    </table>

    <a href="#">Admettre Nouveau Patient</a>

@endsection