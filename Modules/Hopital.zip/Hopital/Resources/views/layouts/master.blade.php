<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title', 'Module Hôpital')</title>

    {{-- Styles --}}
    {{-- Ici, vous inclurez les CSS globaux de l'application ou spécifiques au module --}}
    {{-- <link rel="stylesheet" href="{{ asset('css/app.css') }}"> --}}
    {{-- ou pour des assets spécifiques au module: --}}
    {{-- <link rel="stylesheet" href="{{ asset('modules/hopital/css/hopital.css') }}"> --}}
    @yield('css') {{-- Section pour ajouter des CSS spécifiques à une vue --}}

</head>
<body>

    @yield('content') {{-- C'est ici que le contenu principal de la page sera injecté --}}

    {{-- Scripts --}}
    {{-- Ici, vous inclurez les JS globaux de l'application ou spécifiques au module --}}
    {{-- <script src="{{ asset('js/app.js') }}"></script> --}}
    {{-- ou pour des assets spécifiques au module: --}}
    {{-- <script src="{{ asset('modules/hopital/js/hopital.js') }}"></script> --}}
    @yield('script') {{-- Section pour ajouter des scripts spécifiques à une vue --}}

</body>
</html>