<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse"> {{-- Exemple avec des classes Bootstrap pour une sidebar --}}
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <li class="nav-item">
                {{-- Les URLs sont des placeholders pour le moment, à remplacer par les routes réelles --}}
                <a class="nav-link active" aria-current="page" href="{{ route('hopital.dashboard') }}"> {{-- Exemple de route nommée --}}
                    {{-- Icône --}}
                    Tableau de Bord
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('hopital.patients.index') }}"> {{-- Exemple de route nommée --}}
                     {{-- Icône --}}
                    Patients
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('hopital.appointments.index') }}"> {{-- Exemple de route nommée --}}
                     {{-- Icône --}}
                    Rendez-vous
                </a>
            </li>
             <li class="nav-item">
                <a class="nav-link" href="{{ route('hopital.staff.index') }}"> {{-- Exemple de route nommée --}}
                     {{-- Icône --}}
                    Personnel
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('hopital.inpatients.index') }}"> {{-- Exemple de route nommée --}}
                     {{-- Icône --}}
                    Patients Hospitalisés
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('hopital.beds.index') }}"> {{-- Exemple de route nommée --}}
                     {{-- Icône --}}
                    Lits & Chambres
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('hopital.lab.index') }}"> {{-- Exemple de route nommée --}}
                     {{-- Icône --}}
                    Laboratoire
                </a>
            </li>
             <li class="nav-item">
                <a class="nav-link" href="{{ route('hopital.billing.index') }}"> {{-- Exemple de route nommée --}}
                     {{-- Icône --}}
                    Facturation
                </a>
            </li>
             <li class="nav-item">
                <a class="nav-link" href="{{ route('hopital.emergencies.index') }}"> {{-- Exemple de route nommée --}}
                     {{-- Icône --}}
                    Urgences
                </a>
            </li>
        </ul>

        {{-- Section Rapports (Optionnel) --}}
        {{--
        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Rapports</span>
        </h6>
        <ul class="nav flex-column mb-2">
             <li class="nav-item">
                <a class="nav-link" href="#">
                     Rapports de Ventes
                </a>
            </li>
        </ul>
        --}}
    </div>
</nav>