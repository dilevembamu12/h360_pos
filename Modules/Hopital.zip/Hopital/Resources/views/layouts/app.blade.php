@extends('hopital::layouts.master') {{-- Étend le layout master du module 'hopital' --}}

@section('title')
    @yield('page_title', 'Tableau de bord') - Module Hôpital
@endsection

@section('content')

    {{-- Inclure l'en-tête commun --}}
    @include('hopital::layouts.header')

    <div class="container-fluid"> {{-- Utilisez un container adapté à votre framework CSS (ex: Bootstrap) --}}
        <div class="row">

            {{-- Inclure la navigation (sidebar) --}}
            <div class="col-md-3 col-lg-2 sidebar"> {{-- Exemple pour une sidebar à gauche --}}
                 @include('hopital::layouts.nav')
            </div>

            {{-- Contenu principal de la page --}}
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
                {{-- Un titre pour la page --}}
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">@yield('page_heading', 'Bienvenue')</h1> {{-- Titre spécifique de la page --}}
                </div>

                @yield('page_content') {{-- Le contenu réel de la page --}}
            </main>
        </div>
    </div>

@endsection

{{-- Les sections 'css' et 'script' sont définies dans master.blade.php et peuvent être remplies ici ou dans les vues qui étendent 'app' --}}
@section('css')
    {{-- Ajoutez ici les CSS spécifiques à app.blade.php si nécessaire --}}
    {{-- @parent // Pour conserver les CSS du master --}}
@endsection

@section('script')
    {{-- Ajoutez ici les scripts spécifiques à app.blade.php si nécessaire --}}
    {{-- @parent // Pour conserver les scripts du master --}}
@endsection