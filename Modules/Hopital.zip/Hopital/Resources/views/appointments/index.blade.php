@extends('hopital::layouts.master')

@section('content')
    <h1>Liste des Rendez-vous</h1>

    <p>
        Ceci est la page pour afficher tous les rendez-vous/consultations.
    </p>

    <table>
        <thead>
            <tr>
                <th>Patient</th>
                <th>Médecin</th>
                <th>Date</th>
                <th>Heure</th>
                <th>Statut</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>John DOE</td>
                <td>Dr. Smith</td>
                <td>2023-10-28</td>
                <td>10:00</td>
                <td>Planifié</td>
                <td>
                    <a href="#">Voir</a> | <a href="#">Modifier</a> | <a href="#">Annuler</a>
                </td>
            </tr>
        </tbody>
    </table>

    <a href="#">Ajouter Nouveau Rendez-vous</a>

@endsection