@extends('hopital::layouts.master')

@section('content')
    <h1>Planifier un Nouveau Rendez-vous</h1>

    <p>
        Ceci est le formulaire pour planifier une consultation ou un rendez-vous.
    </p>

    <form action="#" method="POST">
        @csrf

        <div>
            <label for="patient_id">Patient :</label>
            <select id="patient_id" name="patient_id" required>
                {{-- Options des patients --}}
                <option value="1">John DOE</option>
            </select>
        </div>

        <div>
            <label for="staff_id">Médecin/Personnel :</label>
            <select id="staff_id" name="staff_id" required>
                {{-- Options du personnel médical --}}
                <option value="1">Dr. Smith</option>
            </select>
        </div>

        <div>
            <label for="date">Date :</label>
            <input type="date" id="date" name="date" required>
        </div>

        <div>
            <label for="time">Heure :</label>
            <input type="time" id="time" name="time" required>
        </div>

        <button type="submit">Planifier Rendez-vous</button>
    </form>

@endsection