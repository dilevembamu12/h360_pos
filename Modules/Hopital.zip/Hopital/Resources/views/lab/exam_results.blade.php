@extends('hopital::layouts.master')

@section('content')
    <h1>Résultats des Examens de Laboratoire</h1>

     <p>
        Ceci liste les résultats d'examens enregistrés.
    </p>

     <table>
        <thead>
            <tr>
                <th>Numéro Résultat</th>
                <th>Numéro Commande</th>
                <th>Patient</th>
                <th>Type d'Examen</th>
                <th>Date Résultat</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>RES-0001</td>
                <td>EXM-0001</td>
                <td>John DOE</td>
                <td>Analyse sanguine</td>
                <td>2023-10-28</td>
                <td>
                    <a href="#">Voir Résultat</a> | <a href="#">Associer au Dossier Patient</a>
                </td>
            </tr>
        </tbody>
    </table>

@endsection