@extends('hopital::layouts.master')

@section('content')
    <h1>Commandes d'Examens de Laboratoire</h1>

    <p>
        Ceci liste les examens demandés par les médecins.
    </p>

     <table>
        <thead>
            <tr>
                <th>Numéro Commande</th>
                <th>Patient</th>
                <th>Médecin Demandeur</th>
                <th>Type d'Examen</th>
                <th>Date Demande</th>
                <th>Statut</th> {{-- En attente, En cours, Terminé --}}
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>EXM-0001</td>
                <td>John DOE</td>
                <td>Dr. Smith</td>
                <td>Analyse sanguine</td>
                <td>2023-10-27</td>
                <td>En attente</td>
                <td>
                    <a href="#">Voir Détails</a> | <a href="#">Enregistrer Résultat</a>
                </td>
            </tr>
        </tbody>
    </table>

@endsection