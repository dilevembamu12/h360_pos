@extends('layouts.app') {{-- Assurez-vous que 'layouts.app' est le layout principal de votre application --}}

@section('title', __('hopital::lang.hospital_dashboard')) {{-- Titre de la page --}}

@section('content')

{{-- Section de l'en-tête de page avec le titre et potentiellement des boutons --}}
<section class="content-header">
    <h1>@lang('hopital::lang.hospital_dashboard')
        <small>@lang('hopital::lang.overview')</small>
    </h1>
    {{-- Vous pouvez ajouter des breadcrumbs ici si votre template les supporte --}}
    {{-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
    </ol> --}}
</section>

{{-- Section principale du contenu --}}
<section class="content">
    {{-- Affichage des messages d'alerte/succès --}}
    {{-- Assurez-vous que votre layout principal inclut le rendu de ces messages --}}
    @include('layouts.partials.error')

    {{-- Ligne pour les liens rapides ou les actions principales --}}
    <div class="row">
        {{-- Lien rapide : Enregistrer un nouveau patient --}}
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="fa fa-user-plus"></i></span> {{-- Icône Font Awesome --}}
                <div class="info-box-content">
                    <span class="info-box-text">@lang('hopital::lang.register_patient')</span>
                    <span class="info-box-number">
                        <a href="{{ action('\Modules\Hopital\Http\Controllers\PatientController@create') }}">@lang('messages.go_action')</a> {{-- Lien vers la page d'enregistrement --}}
                    </span>
                </div>
            </div>
        </div>

        {{-- Lien rapide : Planifier un rendez-vous --}}
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-green"><i class="fa fa-calendar-plus-o"></i></span> {{-- Icône Font Awesome --}}
                <div class="info-box-content">
                    <span class="info-box-text">@lang('hopital::lang.schedule_appointment')</span>
                    <span class="info-box-number">
                        <a href="{{ action('\Modules\Hopital\Http\Controllers\AppointmentController@create') }}">@lang('messages.go_action')</a>
                    </span>
                </div>
            </div>
        </div>

        {{-- Lien rapide : Gérer les hospitalisations --}}
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-yellow"><i class="fa fa-bed"></i></span> {{-- Icône Font Awesome --}}
                <div class="info-box-content">
                    <span class="info-box-text">@lang('hopital::lang.manage_hospitalizations')</span>
                    <span class="info-box-number">
                        <a href="/hopital/inpatients">@lang('messages.view')</a>
                    </span>
                </div>
            </div>
        </div>

        {{-- Lien rapide : Gérer les factures --}}
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-red"><i class="fa fa-money"></i></span> {{-- Icône Font Awesome --}}
                <div class="info-box-content">
                    <span class="info-box-text">@lang('hopital::lang.manage_billing')</span>
                    <span class="info-box-number">
                        <a href="/hopital/billing">@lang('messages.view')</a>
                    </span>
                </div>
            </div>
        </div>
    </div>

    {{-- Ligne pour les statistiques clés (Info Boxes) --}}
    <div class="row">
        {{-- Statistique : Patients enregistrés aujourd'hui --}}
        @component('components.widget', ['icon' => 'fa fa-users', 'color' => 'bg-blue', 'title' => __('hopital::lang.patients_today')])
            {{-- Ici, vous afficherez le nombre réel en injectant la variable depuis le contrôleur --}}
            <span class="info-box-number">
                {{-- {{ $patients_today_count }} --}} {{-- Exemple : Variable depuis le contrôleur --}}
                50 {{-- Placeholder --}}
            </span>
        @endcomponent

        {{-- Statistique : Hospitalisations Actives --}}
        @component('components.widget', ['icon' => 'fa fa-hospital-o', 'color' => 'bg-purple', 'title' => __('hopital::lang.active_hospitalizations')])
            <span class="info-box-number">
                {{-- {{ $active_hospitalizations_count }} --}}
                120 {{-- Placeholder --}}
            </span>
        @endcomponent

        {{-- Statistique : Lits Disponibles --}}
        @component('components.widget', ['icon' => 'fa fa-bed', 'color' => 'bg-green', 'title' => __('hopital::lang.available_beds')])
            <span class="info-box-number">
                {{-- {{ $available_beds_count }} --}}
                30 {{-- Placeholder --}}
            </span>
        @endcomponent

        {{-- Statistique : Rendez-vous Aujourd'hui --}}
        @component('components.widget', ['icon' => 'fa fa-calendar-check-o', 'color' => 'bg-orange', 'title' => __('hopital::lang.appointments_today')])
            <span class="info-box-number">
                {{-- {{ $appointments_today_count }} --}}
                85 {{-- Placeholder --}}
            </span>
        @endcomponent
    </div>

    {{-- Ligne pour les graphiques ou autres widgets plus grands --}}
    <div class="row">
        {{-- Graphique : Enregistrements de patients sur la période --}}
        <div class="col-sm-12">
            @component('components.widget', ['class' => 'box-primary', 'title' => __('hopital::lang.patient_registrations_trend')])
                {{-- Le graphique sera rendu ici par JS (Highcharts ou similaire) --}}
                <div id="patient_registrations_chart" style="height: 300px;"></div>
            @endcomponent
        </div>
    </div>

    {{-- Ligne pour d'autres widgets (ex: alertes, tâches, résultats récents) --}}
    <div class="row">
         {{-- Widget : Alertes du module Hôpital (ex: lits disponibles faibles, médicaments expirants, résultats critiques) --}}
         <div class="col-md-6">
            @component('components.widget', ['class' => 'box-warning', 'title' => __('hopital::lang.hopital_alerts')])
                <ul>
                    {{-- Boucle sur les alertes depuis le contrôleur --}}
                    {{-- @forelse($alerts as $alert)
                        <li><a href="{{ $alert->link }}">{{ $alert->message }}</a></li>
                    @empty
                        <li>@lang('hopital::lang.no_alerts')</li>
                    @endforelse --}}
                     <li>Alerte : Seulement 5 lits disponibles en réanimation.</li> {{-- Placeholder --}}
                     <li>Alerte : Stock faible pour l'insuline.</li> {{-- Placeholder --}}
                </ul>
            @endcomponent
        </div>

        {{-- Widget : Tâches ou rappels pour le personnel (ex: patients à voir, tâches de facturation) --}}
         <div class="col-md-6">
            @component('components.widget', ['class' => 'box-info', 'title' => __('hopital::lang.staff_tasks')])
                <ul>
                    {{-- Boucle sur les tâches --}}
                    {{-- @forelse($staff_tasks as $task)
                        <li>{{ $task->description }} - Due: {{ $task->due_date }}</li>
                    @empty
                        <li>@lang('hopital::lang.no_tasks')</li>
                    @endforelse --}}
                    <li>Rappel : Examiner les résultats de laboratoire de Patient A.</li> {{-- Placeholder --}}
                    <li>Rappel : Mettre à jour le dossier médical de Patient B.</li> {{-- Placeholder --}}
                </ul>
            @endcomponent
        </div>
    </div>

    {{-- Vous pouvez ajouter d'autres sections ici selon les besoins --}}
    {{-- Par exemple, un tableau des hospitalisations en cours, les derniers résultats de laboratoire, etc. --}}

</section>
{{-- Fin de la section du contenu --}}

@stop

{{-- Section pour les scripts JS spécifiques à ce dashboard --}}
@section('javascript')
    @push('scripts') {{-- Utilise @push pour ajouter des scripts sans écraser ceux du layout principal --}}
    <script type="text/javascript">
        $(document).ready( function(){
            // Initialisation potentielle de graphiques Highcharts ici
            // Exemple (simplifié):
            {{-- var patientRegistrationsChart = Highcharts.chart('patient_registrations_chart', {
                chart: {
                    type: 'line'
                },
                title: {
                    text: '@lang("hopital::lang.patient_registrations_trend")'
                },
                xAxis: {
                    categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'] // Exemple de catégories
                },
                yAxis: {
                    title: {
                        text: '@lang("hopital::lang.number_of_registrations")'
                    }
                },
                series: [{
                    name: '@lang("hopital::lang.new_patients")',
                    data: [100, 120, 90, 150, 200, 180, 250] // Exemple de données
                }]
            }); --}}

            // Assurez-vous d'appeler les fonctions d'initialisation ou de chargement de données ici
            // Pour Highcharts, vous aurez généralement besoin des données passées depuis le contrôleur
            // et d'initialiser le graphique dans le document ready.
            // L'utilisation de @push('scripts') garantit que ce JS s'exécute après le chargement des scripts principaux (incluant jQuery et Highcharts si configuré globalement).
        });
    </script>
    @endpush
@endsection