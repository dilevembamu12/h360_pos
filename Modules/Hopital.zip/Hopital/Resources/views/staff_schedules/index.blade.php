@extends('hopital::layouts.master')

@section('content')
    <h1>Planning du Personnel</h1>

    <p>
        Ceci affiche les horaires de travail et les affectations du personnel.
    </p>

    {{-- Un calendrier ou un tableau des horaires --}}
    <table>
        <thead>
            <tr>
                <th>Personnel</th>
                <th>Date</th>
                <th>Heure Début</th>
                <th>Heure Fin</th>
                <th>Département</th>
                <th>Patients Affectés</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Dr. Smith</td>
                <td>2023-10-28</td>
                <td>08:00</td>
                <td>16:00</td>
                <td>Consultations externes</td>
                <td>John DOE, Jane DOE...</td>
            </tr>
        </tbody>
    </table>

@endsection