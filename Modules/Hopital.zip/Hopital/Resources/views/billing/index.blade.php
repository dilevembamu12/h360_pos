@extends('hopital::layouts.master')

@section('content')
    <h1>Gestion de la Facturation</h1>

    <p>
        Ceci affiche la liste des factures et leur statut (payé, en attente, assurance).
    </p>

    <table>
        <thead>
            <tr>
                <th>Numéro Facture</th>
                <th>Patient</th>
                <th>Date</th>
                <th>Montant Total</th>
                <th>Statut</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>FAC-0001</td>
                <td>John DOE</td>
                <td>2023-10-27</td>
                <td>150.00 €</td>
                <td>En attente de paiement</td>
                <td>
                    <a href="#">Voir</a> | <a href="#">Enregistrer Paiement</a> | <a href="#">Soumettre Assurance</a>
                </td>
            </tr>
        </tbody>
    </table>

    <a href="#">Créer Nouvelle Facture</a> {{-- Par exemple, pour des services non liés à un rendez-vous --}}

@endsection