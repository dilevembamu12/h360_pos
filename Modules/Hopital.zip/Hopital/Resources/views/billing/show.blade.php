@extends('hopital::layouts.master')

@section('content')
    <h1>Détails de la Facture : FAC-0001</h1>

    <p>Patient : John DOE</p>
    <p>Date : 2023-10-27</p>
    <p>Statut : En attente de paiement</p>

    <h2>Articles Facturés</h2>
    <table>
        <thead>
            <tr>
                <th>Description</th>
                <th>Quantité</th>
                <th>Prix Unitaire</th>
                <th>Sous-total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Consultation Généraliste</td>
                <td>1</td>
                <td>100.00 €</td>
                <td>100.00 €</td>
            </tr>
            <tr>
                <td>Médicament (Paracétamol)</td>
                <td>1</td>
                <td>10.00 €</td>
                <td>10.00 €</td>
            </tr>
            {{-- Ajoutez d'autres articles (examens, jours d'hospitalisation, etc.) --}}
        </tbody>
        <tfoot>
             <tr>
                <td colspan="3" align="right">Total :</td>
                <td>150.00 €</td>
            </tr>
        </tfoot>
    </table>

    {{-- Informations Assurance / Paiement --}}

    <a href="#">Retour à la Liste des Factures</a>
    <a href="#">Enregistrer Paiement</a>
    <a href="#">Soumettre à l'Assurance</a>
    <a href="#">Imprimer Facture</a>

@endsection