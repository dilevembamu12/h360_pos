@extends('hopital::layouts.master')

@section('content')
    <h1>Détails du Patient : John DOE</h1> {{-- Exemple --}}

    <p>
        Ceci affiche les informations détaillées du patient.
    </p>

    <h2>Informations Générales</h2>
    <p>Nom : DOE</p>
    <p>Prénom : John</p>
    <p>Type : Ambulatoire</p>
    {{-- Ajoutez d'autres informations --}}

    <h2>Fiche de Traitement</h2>
    <p>
        Ceci contient l'histoire médicale, les allergies, les médicaments actuels et les résultats d'examen.
    </p>

    <h3>Histoire Médicale</h3>
    {{-- Liste de l'histoire médicale --}}
    <p>Date : 2023-10-27, Diagnostic : Rhume</p>

    <h3>Allergies</h3>
    {{-- Liste des allergies --}}
    <p>Allergie aux arachides</p>

    <h3>Médicaments Actuels</h3>
    {{-- Liste des médicaments --}}
    <p>Paracétamol (500mg, 3x/jour)</p>

    <h3>Résultats d'Examens Récents</h3>
    {{-- Liste des résultats --}}
    <p>Examen sanguin du 2023-10-26 : Normal</p>

    {{-- Liens vers d'autres sections comme les rendez-vous, factures, etc. --}}

    <a href="#">Modifier Patient</a>
    <a href="#">Retour à la Liste des Patients</a>

@endsection