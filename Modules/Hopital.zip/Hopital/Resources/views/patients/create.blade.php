@extends('hopital::layouts.master')

@section('content')
    <h1>Ajouter un Nouveau Patient</h1>

    <p>
        Ceci est le formulaire pour enregistrer un nouveau patient.
    </p>

    <form action="#" method="POST">
        @csrf {{-- Token CSRF pour la sécurité --}}

        {{-- Champs du formulaire placeholder --}}
        <div>
            <label for="nom">Nom :</label>
            <input type="text" id="nom" name="nom" required>
        </div>

        <div>
            <label for="prenom">Prénom :</label>
            <input type="text" id="prenom" name="prenom" required>
        </div>

        <div>
            <label for="type">Type :</label>
            <select id="type" name="type">
                <option value="ambulatoire">Ambulatoire</option>
                <option value="hospitalise">Hospitalisé</option>
            </select>
        </div>

        {{-- Ajoutez d'autres champs selon le scénario (histoire médicale, allergies, etc.) --}}

        <button type="submit">Enregistrer Patient</button>
    </form>

@endsection