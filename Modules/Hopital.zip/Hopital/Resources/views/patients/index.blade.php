@extends('hopital::layouts.master') {{-- Supposons un layout maître pour le module --}}

@section('content')
    <h1>Liste des Patients</h1>

    <p>
        Ceci est la page pour lister tous les patients enregistrés dans le système.
    </p>

    {{-- Table placeholder --}}
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Type</th> {{-- Ambulatoire/Hospitalisé --}}
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            {{-- Boucle sur les patients ici --}}
            <tr>
                <td>1</td>
                <td>DOE</td>
                <td>John</td>
                <td>Ambulatoire</td>
                <td>
                    <a href="#">Voir</a> | <a href="#">Modifier</a>
                </td>
            </tr>
            {{-- Fin de la boucle --}}
        </tbody>
    </table>

    <a href="#">Ajouter Nouveau Patient</a>

@endsection

@section('scripts')
    @parent
    {{-- Scripts JS spécifiques à cette page (ex: datatables) --}}
@endsection