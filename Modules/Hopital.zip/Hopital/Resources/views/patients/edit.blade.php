@extends('hopital::layouts.master')

@section('content')
    <h1>Modifier Patient : John DOE</h1> {{-- Exemple --}}

    <p>
        Ceci est le formulaire pour modifier les informations d'un patient existant.
    </p>

    <form action="#" method="POST">
        @csrf {{-- Token CSRF --}}
        @method('PUT') {{-- Méthode PUT pour la mise à jour --}}

        {{-- Champs du formulaire pré-remplis avec les données du patient --}}
        <div>
            <label for="nom">Nom :</label>
            <input type="text" id="nom" name="nom" value="DOE" required>
        </div>

        <div>
            <label for="prenom">Prénom :</label>
            <input type="text" id="prenom" name="prenom" value="John" required>
        </div>

        <div>
            <label for="type">Type :</label>
            <select id="type" name="type">
                <option value="ambulatoire" selected>Ambulatoire</option>
                <option value="hospitalise">Hospitalisé</option>
            </select>
        </div>

        {{-- Ajoutez d'autres champs pré-remplis --}}

        <button type="submit">Mettre à Jour Patient</button>
    </form>

@endsection