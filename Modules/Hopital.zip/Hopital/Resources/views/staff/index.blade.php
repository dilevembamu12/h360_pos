@extends('hopital::layouts.master')

@section('content')
    <h1>Liste du Personnel Médical</h1>

    <p>
        Ceci affiche la liste des médecins, infirmières et autres personnels.
    </p>

    <table>
        <thead>
            <tr>
                <th>Nom</th>
                <th>Rôle</th>
                <th>Spécialité</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Dr. Smith</td>
                <td>Médecin</td>
                <td>Généraliste</td>
                <td>
                    <a href="#">Voir Planning</a> | <a href="#">Modifier</a>
                </td>
            </tr>
             <tr>
                <td>Inf. Dubois</td>
                <td>Infirmière</td>
                <td>Soins Généraux</td>
                <td>
                    <a href="#">Voir Planning</a> | <a href="#">Modifier</a>
                </td>
            </tr>
        </tbody>
    </table>

    <a href="#">Ajouter Nouveau Personnel</a>

@endsection