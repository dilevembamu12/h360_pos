@extends('hopital::layouts.master')

@section('content')
    <h1>Gestion des Lits et des Chambres</h1>

    <p>
        Ceci affiche l'état d'occupation des lits.
    </p>

     <table>
        <thead>
            <tr>
                <th>Chambre</th>
                <th>Lit</th>
                <th>Statut</th> {{-- Occupé, Libre, Maintenance --}}
                <th>Patient (si occupé)</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Chambre 101</td>
                <td>Lit A</td>
                <td>Occupé</td>
                <td>Jane DOE</td>
                <td>
                    <a href="#">Voir Détails</a>
                </td>
            </tr>
             <tr>
                <td>Chambre 101</td>
                <td>Lit B</td>
                <td>Libre</td>
                <td>-</td>
                <td>
                    <a href="#">Assigner Patient</a>
                </td>
            </tr>
        </tbody>
    </table>

    <a href="#">Ajouter Chambre/Lit</a>

@endsection