@extends('hopital::layouts.master')

@section('content')
    <h1>Tableau de Bord des Urgences</h1>

    <p>
        Ceci est un aperçu des urgences actives et des alertes.
    </p>

    <h2>Urgences Actives</h2>
     <table>
        <thead>
            <tr>
                <th>Type d'Urgence</th>
                <th>Patient (si connu)</th>
                <th>Localisation</th>
                <th>Heure Début</th>
                <th>Statut</th> {{-- Nouvelle, En cours, Résolue --}}
                <th>Personnel Assigné</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Code Bleu (Arrêt cardiaque)</td>
                <td>Patient inconnu</td> {{-- Peut ne pas être identifié immédiatement --}}
                <td>Réanimation</td>
                <td>{{ now()->subMinutes(5)->format('H:i') }}</td>
                <td>En cours</td>
                <td>Dr. Emergency, Inf. Quick</td>
                <td>
                    <a href="#">Voir Détails</a> | <a href="#">Mettre à Jour Statut</a> | <a href="#">Déclarer Résolue</a>
                </td>
            </tr>
        </tbody>
    </table>

    {{-- Formulaire rapide pour signaler une urgence --}}
    <h2>Signaler une Nouvelle Urgence</h2>
    <form action="#" method="POST">
        @csrf
        {{-- Champs rapides (type, localisation, etc.) --}}
        <button type="submit">Signaler Urgence</button>
    </form>

@endsection