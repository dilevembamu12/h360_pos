console.log('Hopital Module Assets Loaded!');

// Vous pouvez importer d'autres fichiers JS ici si nécessaire
// import './another-script';

// Si vous utilisez Alpine.js, vous pourriez l'initialiser ici
// import Alpine from 'alpinejs';
// window.Alpine = Alpine;
// Alpine.start();

// Si vous utilisez Axios, vous pouvez le configurer ou l'utiliser ici
// import axios from 'axios';
// window.axios = axios;
// window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';