<?php

namespace Modules\Hopital\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class InsuranceProvidersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        DB::table('hopital_insurance_providers')->insert([
            [
                'name' => 'Assurance Santé Plus',
                'contact_person' => 'Madame Claire Durant',
                'phone' => '0800 11 22 33',
                'email' => 'contact@assurancesanteplus.com',
                'address' => '123 Rue de la Santé, Ville',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Mutuelle Bien-être',
                'contact_person' => 'Monsieur David Lefevre',
                'phone' => '0800 44 55 66',
                'email' => 'info@mutuellebienetre.com',
                'address' => '456 Avenue du Bien-être, Ville',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}