<?php

namespace Modules\Hopital\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class StaffTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        DB::table('hopital_staff')->insert([
            [
                'first_name' => 'Dr. Jean',
                'last_name' => 'Dupont',
                'role' => 'Physician',
                'specialty' => 'Cardiology',
                'phone' => '0123456789',
                'email' => 'jean.dupont@hopital.com',
                'registration_number' => 'MD-12345',
                'user_id' => null, // Liaison à un user existant si applicable, sinon null
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'first_name' => 'Dr. Sophie',
                'last_name' => 'Martin',
                'role' => 'Physician',
                'specialty' => 'Pediatrics',
                'phone' => '0987654321',
                'email' => 'sophie.martin@hopital.com',
                'registration_number' => 'MD-67890',
                 'user_id' => null,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'first_name' => 'Marie',
                'last_name' => 'Dubois',
                'role' => 'Nurse',
                'specialty' => null,
                'phone' => '0601020304',
                'email' => 'marie.dubois@hopital.com',
                'registration_number' => 'RN-11223',
                 'user_id' => null,
                'created_at' => now(),
                'updated_at' => now(),
            ],
             [
                'first_name' => 'Pierre',
                'last_name' => 'Petit',
                'role' => 'Admin',
                'specialty' => null,
                'phone' => '0705060708',
                'email' => 'pierre.petit@hopital.com',
                'registration_number' => null,
                 'user_id' => null,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        // Note : Pour lier ces staff à des utilisateurs existants (si 'user_id' n'est pas null),
        // vous devriez soit créer les utilisateurs dans un seeder précédent et récupérer leurs IDs,
        // soit mettre à jour ces enregistrements après la création des utilisateurs.
    }
}