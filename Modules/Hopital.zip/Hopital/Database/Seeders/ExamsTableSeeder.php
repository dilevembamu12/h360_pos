<?php

namespace Modules\Hopital\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ExamsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        DB::table('hopital_exams')->insert([
            [
                'name' => 'Blood Count (CBC)',
                'description' => 'Complete Blood Count',
                'price' => 35.00,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Urine Analysis',
                'description' => 'Standard Urine Analysis',
                'price' => 25.00,
                'created_at' => now(),
                'updated_at' => now(),
            ],
             [
                'name' => 'X-Ray (Chest)',
                'description' => 'Chest X-Ray',
                'price' => 75.00,
                'created_at' => now(),
                'updated_at' => now(),
            ],
             [
                'name' => 'MRI (Brain)',
                'description' => 'Magnetic Resonance Imaging of the Brain',
                'price' => 500.00,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'ECG/EKG',
                'description' => 'Electrocardiogram',
                'price' => 50.00,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}