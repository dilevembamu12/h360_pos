<?php

namespace Modules\Hopital\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class RoomsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        DB::table('hopital_rooms')->insert([
            [
                'room_number' => '101',
                'room_type' => 'Standard',
                'capacity' => 2,
                'description' => 'Chambre standard double.',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'room_number' => '102',
                'room_type' => 'Standard',
                'capacity' => 2,
                'description' => 'Chambre standard double.',
                'created_at' => now(),
                'updated_at' => now(),
            ],
             [
                'room_number' => '201',
                'room_type' => 'Private',
                'capacity' => 1,
                'description' => 'Chambre individuelle privée.',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'room_number' => 'ICU-1',
                'room_type' => 'ICU',
                'capacity' => 1,
                'description' => 'Unité de Soins Intensifs.',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}