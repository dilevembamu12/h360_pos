<?php

namespace Modules\Hopital\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class BedsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        // Récupérer les IDs des chambres pour lier les lits
        $room101Id = DB::table('hopital_rooms')->where('room_number', '101')->first()->id;
        $room102Id = DB::table('hopital_rooms')->where('room_number', '102')->first()->id;
        $room201Id = DB::table('hopital_rooms')->where('room_number', '201')->first()->id;
        $roomICU1Id = DB::table('hopital_rooms')->where('room_number', 'ICU-1')->first()->id;


        DB::table('hopital_beds')->insert([
            [
                'room_id' => $room101Id,
                'bed_number' => 'Bed A',
                'status' => 'available',
                'bed_type' => 'Standard',
                'created_at' => now(),
                'updated_at' => now(),
            ],
             [
                'room_id' => $room101Id,
                'bed_number' => 'Bed B',
                'status' => 'available',
                'bed_type' => 'Standard',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'room_id' => $room102Id,
                'bed_number' => 'Bed A',
                'status' => 'occupied', // Exemple de lit déjà occupé
                'bed_type' => 'Standard',
                'created_at' => now(),
                'updated_at' => now(),
            ],
             [
                'room_id' => $room102Id,
                'bed_number' => 'Bed B',
                'status' => 'available',
                'bed_type' => 'Standard',
                'created_at' => now(),
                'updated_at' => now(),
            ],
             [
                'room_id' => $room201Id,
                'bed_number' => 'Bed 1',
                'status' => 'available',
                'bed_type' => 'Private',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'room_id' => $roomICU1Id,
                'bed_number' => 'Bed 1',
                'status' => 'maintenance', // Exemple de lit en maintenance
                'bed_type' => 'ICU',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}