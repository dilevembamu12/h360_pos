<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Table pour l'historique médical général (maladies passées, chirurgies, etc.)
        Schema::create('hopital_patient_medical_histories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('hopital_patients')->cascadeOnDelete();
            $table->string('history_type'); // e.g., 'Past Illness', 'Surgical History', 'Family History'
            $table->text('details');
            $table->date('recorded_date')->nullable(); // Date pertinente de l'événement historique
            $table->foreignId('recorded_by')->nullable()->constrained('hopital_staff')->onDelete('set null'); // Qui a enregistré l'information

            $table->timestamps();
        });

        // Table pour les allergies du patient
        Schema::create('hopital_patient_allergies', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('hopital_patients')->cascadeOnDelete();
            $table->string('allergy_name');
            $table->text('reaction')->nullable();
            $table->string('severity')->nullable(); // e.g., 'Mild', 'Moderate', 'Severe'
            $table->date('recorded_date')->nullable();
             $table->foreignId('recorded_by')->nullable()->constrained('hopital_staff')->onDelete('set null');

            $table->timestamps();
        });

        // Table pour les médicaments que le patient prend actuellement (avant la consultation/hospitalisation)
        Schema::create('hopital_patient_medications', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('hopital_patients')->cascadeOnDelete();
            $table->string('medication_name');
            $table->string('dosage')->nullable();
            $table->string('frequency')->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->text('notes')->nullable();
            $table->foreignId('recorded_by')->nullable()->constrained('hopital_staff')->onDelete('set null');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hopital_patient_medical_histories');
        Schema::dropIfExists('hopital_patient_allergies');
        Schema::dropIfExists('hopital_patient_medications');
    }
};