<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_patients', function (Blueprint $table) {
            $table->id();
            $table->string('first_name');
            $table->string('last_name');
            $table->date('date_of_birth')->nullable();
            $table->string('gender')->nullable(); // e.g., 'Male', 'Female', 'Other'
            $table->string('phone')->nullable();
            $table->string('email')->nullable();
            $table->text('address')->nullable();
            $table->string('patient_code')->unique()->nullable(); // Code unique interne ou externe
            $table->boolean('is_inpatient')->default(false); // true si hospitalisé, false si ambulatoire
            $table->timestamp('registration_date')->useCurrent();

            $table->timestamps(); // Adds created_at and updated_at
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('hopital_patients', function (Blueprint $table) {
            // Supprime la colonne deleted_at
            $table->dropSoftDeletes();
        });
        Schema::dropIfExists('hopital_patients');

        
    }
};