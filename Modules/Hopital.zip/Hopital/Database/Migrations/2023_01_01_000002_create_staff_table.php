<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_staff', function (Blueprint $table) {
            $table->id();
            // Liaison possible avec la table 'users' de l'application principale
            // Adapter 'users' et la colonne 'id' si nécessaire
            //$table->foreignId('user_id')->nullable()->constrained('users')->onDelete('set null'); // Assumes a 'users' table exists
            //$table->integer('user_id')->index();
        

            $table->string('first_name');
            $table->string('last_name');
            $table->string('role'); // e.g., 'Physician', 'Nurse', 'Admin', 'Lab Technician'
            $table->string('specialty')->nullable(); // For Physicians
            $table->string('phone')->nullable();
            $table->string('email')->nullable();
            $table->string('registration_number')->nullable(); // Numéro d'enregistrement professionnel
            
            $table->timestamps();

            // La colonne pour la clé étrangère DOIT être unsignedBigInteger
            $table->unsignedInteger('user_id')->nullable(); // <-- C'est la CORRECTION

            // Définition de la clé étrangère
            $table->foreign('user_id')
                  ->references('id')->on('users')
                  ->onDelete('set null'); // <-- Doit correspondre à nullable() ci-dessus

                  $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('hopital_staff', function (Blueprint $table) {
            // Supprime la colonne deleted_at
            $table->dropSoftDeletes();
        });
        Schema::dropIfExists('hopital_staff');
    }
};