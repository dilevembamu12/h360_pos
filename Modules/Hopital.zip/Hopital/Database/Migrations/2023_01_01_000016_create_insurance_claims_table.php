<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_insurance_claims', function (Blueprint $table) {
            $table->id();
            $table->foreignId('bill_id')->constrained('hopital_bills')->cascadeOnDelete(); // La facture concernée par la demande
            $table->foreignId('insurance_provider_id')->constrained('hopital_insurance_providers')->cascadeOnDelete();

            $table->string('claim_number')->unique()->nullable(); // Numéro de demande de l'assurance
            $table->timestamp('claim_date')->useCurrent(); // Date à laquelle la demande a été créée dans le système
            $table->timestamp('submission_date')->nullable(); // Date réelle de soumission à l'assurance
            $table->string('status')->default('submitted'); // e.g., 'submitted', 'approved', 'rejected', 'paid', 'pending'
            $table->decimal('approved_amount', 10, 2)->nullable(); // Montant approuvé par l'assurance
            $table->timestamp('payment_date')->nullable(); // Date de paiement par l'assurance
            $table->text('notes')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hopital_insurance_claims');
    }
};