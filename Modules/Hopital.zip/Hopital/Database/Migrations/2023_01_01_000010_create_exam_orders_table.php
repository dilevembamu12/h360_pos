<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_exam_orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('hopital_patients')->cascadeOnDelete();
            $table->foreignId('exam_id')->constrained('hopital_exams')->cascadeOnDelete();
            $table->foreignId('ordered_by')->nullable()->constrained('hopital_staff')->onDelete('set null'); // Médecin qui a commandé l'examen
            $table->foreignId('appointment_id')->nullable()->constrained('hopital_appointments')->onDelete('set null'); // Liaison avec un rendez-vous si applicable

            $table->timestamp('order_date')->useCurrent();
            $table->string('status')->default('ordered'); // e.g., 'ordered', 'sample_collected', 'processing', 'completed', 'cancelled'
            $table->text('notes')->nullable();
            $table->date('sample_collection_date')->nullable();
            $table->timestamp('completed_at')->nullable(); // Date/heure de complétion de l'examen

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hopital_exam_orders');
    }
};