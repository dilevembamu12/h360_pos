<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_bill_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('bill_id')->constrained('hopital_bills')->cascadeOnDelete();

            $table->string('description'); // Description de l'élément (Consultation, Médicament X, Examen Y, Séjour journalier)
            $table->string('item_type')->nullable(); // e.g., 'consultation', 'medication', 'exam', 'room_stay', 'procedure'
            $table->integer('quantity')->default(1);
            $table->decimal('unit_price', 10, 2);
            $table->decimal('line_total', 10, 2);

            // Pour lier l'élément facturé à sa source (rendez-vous, prescription, examen, etc.)
            // Relation polymorphique
            $table->nullableMorphs('source'); // Creates source_id and source_type columns

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hopital_bill_items');
    }
};