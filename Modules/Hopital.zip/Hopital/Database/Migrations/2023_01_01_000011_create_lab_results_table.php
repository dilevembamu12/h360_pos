<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_lab_results', function (Blueprint $table) {
            $table->id();
            $table->foreignId('exam_order_id')->constrained('hopital_exam_orders')->cascadeOnDelete();
            $table->timestamp('result_date')->useCurrent();
            $table->json('result_data')->nullable(); // Stocker les résultats bruts (JSON flexible)
            

            //$table->string('file_path')->nullable(); // Chemin vers un fichier de rapport (PDF, image, etc.)

            
            $table->text('interpretation')->nullable(); // Interprétation du médecin/technicien
            
            // Colonne 'status' qui manquait
            // Possible statuts : 'pending', 'processing', 'completed', 'validated', 'cancelled'
            $table->string('status')->default('pending');


            // Qui a validé/revu le résultat (lien optionnel vers le personnel)
            //$table->foreignId('validated_by')->nullable()->constrained('users')->onDelete('set null'); // Assurez-vous que 'users' est la table du personnel/utilisateurs

            
            $table->foreignId('interpreted_by')->nullable()->constrained('hopital_staff')->onDelete('set null'); // Personnel qui a interprété les résultats

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hopital_lab_results');
    }
};