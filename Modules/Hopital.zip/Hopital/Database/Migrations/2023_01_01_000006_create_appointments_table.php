<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_appointments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('hopital_patients')->cascadeOnDelete();
            $table->foreignId('staff_id')->nullable()->constrained('hopital_staff')->onDelete('set null'); // Médecin/Personnel assigné

            $table->dateTime('appointment_at'); // Date et heure du rendez-vous
            $table->string('type')->nullable(); // e.g., 'Consultation', 'Follow-up', 'Procedure'
            $table->string('status')->default('scheduled'); // e.g., 'scheduled', 'completed', 'cancelled', 'no-show'
            $table->text('notes')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('hopital_staff')->onDelete('set null'); // Qui a créé le rendez-vous

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hopital_appointments');
    }
};