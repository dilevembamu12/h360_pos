<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_prescriptions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('hopital_patients')->cascadeOnDelete();
            $table->foreignId('prescribed_by')->nullable()->constrained('hopital_staff')->onDelete('set null'); // Le médecin qui a prescrit
            $table->foreignId('appointment_id')->nullable()->constrained('hopital_appointments')->onDelete('set null'); // Liaison avec un rendez-vous si applicable

            $table->string('medication_name');
            $table->string('dosage')->nullable();
            $table->string('frequency')->nullable();
            $table->string('duration')->nullable();
            $table->text('notes')->nullable();
            $table->date('prescription_date')->useCurrent();
            $table->string('status')->default('active'); // e.g., 'active', 'filled', 'cancelled'

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hopital_prescriptions');
    }
};