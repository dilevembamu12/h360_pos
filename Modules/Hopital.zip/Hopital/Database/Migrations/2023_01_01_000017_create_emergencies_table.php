<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_emergencies', function (Blueprint $table) {
            $table->id();
            // Le patient peut être null pour les cas non identifiés immédiatement
            $table->foreignId('patient_id')->nullable()->constrained('hopital_patients')->onDelete('set null');
            $table->timestamp('reported_at')->useCurrent(); // Date/heure de début de l'urgence
            $table->string('type'); // e.g., 'Cardiac Arrest', 'Accident', 'Stroke', 'Severe Trauma'
            $table->string('severity')->nullable(); // e.g., 'Critical', 'Urgent', 'Semi-urgent'
            $table->text('initial_assessment')->nullable();
            $table->string('status')->default('active'); // e.g., 'active', 'resolved', 'stable', 'deceased'
            $table->timestamp('resolved_at')->nullable(); // Date/heure de résolution de l'urgence

            // Personnel impliqué - peut être géré via une table pivot si plusieurs
            $table->foreignId('handled_by')->nullable()->constrained('hopital_staff')->onDelete('set null'); // Personnel principal ayant géré le cas
            $table->text('notes')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hopital_emergencies');
    }
};