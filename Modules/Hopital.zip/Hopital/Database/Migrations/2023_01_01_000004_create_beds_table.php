<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_beds', function (Blueprint $table) {
            $table->id();
            $table->foreignId('room_id')->constrained('hopital_rooms')->cascadeOnDelete();
            $table->string('bed_number'); // e.g., 'Bed 1', 'A'
            $table->string('status')->default('available'); // e.g., 'available', 'occupied', 'maintenance'
            $table->string('bed_type')->nullable(); // e.g., 'Standard', 'ICU', 'Pediatric'

            $table->timestamps();

            $table->softDeletes();

            // Ensure uniqueness of bed number within a room
            $table->unique(['room_id', 'bed_number']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('hopital_beds', function (Blueprint $table) {
            // Supprime la colonne deleted_at
            $table->dropSoftDeletes();
        });
        Schema::dropIfExists('hopital_beds');
    }
};