<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_bills', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('hopital_patients')->cascadeOnDelete();
            $table->string('bill_number')->unique();
            $table->timestamp('bill_date')->useCurrent();
            $table->date('due_date')->nullable();
            $table->decimal('total_amount', 10, 2)->default(0);
            $table->decimal('paid_amount', 10, 2)->default(0);
            $table->decimal('due_amount', 10, 2)->default(0);
            $table->string('status')->default('pending'); // e.g., 'pending', 'paid', 'partial', 'cancelled', 'insurance_claim'
            $table->foreignId('insurance_provider_id')->nullable()->constrained('hopital_insurance_providers')->onDelete('set null'); // Si une assurance est impliquée

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hopital_bills');
    }
};