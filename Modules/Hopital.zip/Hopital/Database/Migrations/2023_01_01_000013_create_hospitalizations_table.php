<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_hospitalizations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('hopital_patients')->cascadeOnDelete();
            $table->foreignId('bed_id')->nullable()->constrained('hopital_beds')->onDelete('set null'); // Le lit assigné (peut changer ou être null si pas encore assigné)
            $table->foreignId('admitting_physician_id')->nullable()->constrained('hopital_staff')->onDelete('set null'); // Médecin responsable de l'admission

            $table->timestamp('admission_date')->useCurrent();
            $table->timestamp('discharge_date')->nullable(); // Date/heure de sortie
            $table->text('diagnosis')->nullable(); // Diagnostic principal
            $table->text('treatment_plan')->nullable(); // Plan de traitement
            $table->string('status')->default('admitted'); // e.g., 'admitted', 'discharged', 'transferred'
            $table->text('discharge_summary')->nullable(); // Résumé de sortie

            $table->timestamps();

            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('hopital_hospitalizations', function (Blueprint $table) {
            // Supprime la colonne deleted_at
            $table->dropSoftDeletes();
        });
        Schema::dropIfExists('hopital_hospitalizations');
    }
};