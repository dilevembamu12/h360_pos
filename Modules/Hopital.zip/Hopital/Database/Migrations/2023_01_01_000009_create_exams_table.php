<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hopital_exams', function (Blueprint $table) {
            $table->id();
            $table->string('name'); // e.g., 'Blood Test', 'X-Ray', 'MRI'
            $table->text('description')->nullable();
            $table->decimal('price', 10, 2)->nullable(); // Peut être facturé

            $table->timestamps();

            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('hopital_exams', function (Blueprint $table) {
            // Supprime la colonne deleted_at
            $table->dropSoftDeletes();
        });
        Schema::dropIfExists('hopital_exams');
    }
};