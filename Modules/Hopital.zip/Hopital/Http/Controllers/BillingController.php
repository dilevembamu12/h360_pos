<?php

namespace Modules\Hopital\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\Bill;
use Modules\Hopital\Entities\Patient; // Assurez-vous d'avoir le modèle Patient
// use Modules\Hopital\Entities\Service; // Modèle pour les services/actes facturables (consultation, soin, etc.)
// use Modules\Hopital\Entities\Medication; // Si les médicaments sont facturables
use Modules\Hopital\Http\Requests\StoreBillRequest; // À créer
// use Modules\Hopital\Http\Requests\AddBillItemRequest; // À créer pour ajouter des éléments à une facture

class BillingController extends Controller
{
    /**
     * Display a listing of bills.
     * Affiche la liste des factures.
     * @return Renderable
     */
    public function index()
    {
        // Logique pour récupérer et afficher la liste des factures
        $bills = Bill::with('patient')->get(); // Exemple
        return view('hopital::billing.index', compact('bills'));
    }

    /**
     * Show the form for creating a new bill.
     * Affiche le formulaire de création d'une nouvelle facture.
     * @return Renderable
     */
    public function create()
    {
        // Logique pour récupérer les patients et les éléments facturables (services, médicaments)
        $patients = Patient::all();
        // $services = Service::all(); // Exemple
        // $medications = Medication::all(); // Exemple
        return view('hopital::billing.create', compact('patients')); //, 'services', 'medications'));
    }

    /**
     * Store a newly created bill in storage.
     * Enregistre une nouvelle facture.
     * @param StoreBillRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreBillRequest $request)
    {
        // Logique pour créer une facture et y associer les éléments facturables
        // Créer la facture principale
        $bill = Bill::create($request->validated());

        // Ajouter les éléments à la facture (à implémenter en fonction de la structure de la requête)
        // foreach($request->items as $item) {
        //     $bill->items()->create($item);
        // }

        return redirect()->route('hopital.billing.show', $bill->id)
                         ->with('success', 'Facture créée avec succès.');
    }

    /**
     * Show the specified bill.
     * Affiche les détails d'une facture.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        // Logique pour trouver la facture et charger ses éléments
        $bill = Bill::with(['patient', 'items'])->findOrFail($id); // Assurez-vous de la relation 'items'
        return view('hopital::billing.show', compact('bill'));
    }

    /**
     * Show the form for editing the specified bill.
     * Affiche le formulaire d'édition d'une facture.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        // Logique pour trouver la facture à éditer et les éléments facturables
        $bill = Bill::with('items')->findOrFail($id);
        // $patients = Patient::all(); // Utile si on peut changer le patient? Probablement pas.
        // $services = Service::all();
        // $medications = Medication::all();
        return view('hopital::billing.edit', compact('bill')); //, 'patients', 'services', 'medications'));
    }

    /**
     * Update the specified bill in storage.
     * Met à jour une facture.
     * @param Request $request // Utiliser UpdateBillRequest à créer
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id) // Remplacer Request par UpdateBillRequest
    {
        // Logique pour trouver et mettre à jour la facture et ses éléments
        $bill = Bill::with('items')->findOrFail($id);
        $bill->update($request->except('items')); // Exclure les éléments si gérés séparément

        // Logique pour mettre à jour/ajouter/supprimer les éléments de facture
        // Gérer les $request->items ici

        return redirect()->route('hopital.billing.show', $id)
                         ->with('success', 'Facture mise à jour avec succès.');
    }

    /**
     * Remove the specified bill from storage.
     * Supprime une facture (attention aux implications financières).
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        // Logique pour trouver et supprimer la facture (avec ses éléments)
        $bill = Bill::findOrFail($id);
        $bill->delete(); // Assurez-vous que la suppression en cascade est configurée ou supprimez les éléments d'abord

        return redirect()->route('hopital.billing.index')
                         ->with('success', 'Facture supprimée avec succès.');
    }

    // Méthodes spécifiques
    /**
     * Add item to a bill.
     * Ajoute un élément (service, médicament) à une facture existante.
     * @param AddBillItemRequest $request // À créer
     * @param int $bill_id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function addItem(Request $request, $bill_id) // Remplacer Request par AddBillItemRequest
    {
        // $bill = Bill::findOrFail($bill_id);
        // $bill->items()->create($request->validated());
        // return back()->with('success', 'Élément ajouté à la facture.');
        // Placeholder
    }

    /**
     * Process payment for a bill.
     * Enregistre un paiement pour une facture.
     * @param Request $request // À créer pour les détails du paiement
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function processPayment(Request $request, $id)
    {
        // $bill = Bill::findOrFail($id);
        // Logique pour enregistrer le paiement, mettre à jour le statut de la facture
        // $bill->payments()->create($request->validated()); // Exemple si vous avez une table de paiements
        // $bill->status = 'paid'; // Exemple
        // $bill->save();
        // return back()->with('success', 'Paiement enregistré.');
        // Placeholder
    }
}