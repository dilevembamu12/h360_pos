<?php

namespace Modules\Hopital\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\Staff; // Ou utiliser/étendre le modèle User de l'application principale
use Modules\Hopital\Http\Requests\StoreStaffRequest; // À créer
use Modules\Hopital\Http\Requests\UpdateStaffRequest; // À créer

class StaffController extends Controller
{
    /**
     * Display a listing of staff.
     * Affiche la liste du personnel médical.
     * @return Renderable
     */
    public function index()
    {
        // Logique pour récupérer et afficher la liste du personnel
        $staff = Staff::all(); // Exemple
        return view('hopital::staff.index', compact('staff'));
    }

    /**
     * Show the form for creating new staff.
     * Affiche le formulaire de création d'un nouveau membre du personnel.
     * @return Renderable
     */
    public function create()
    {
        return view('hopital::staff.create');
    }

    /**
     * Store a newly created staff member in storage.
     * Enregistre un nouveau membre du personnel.
     * @param StoreStaffRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreStaffRequest $request)
    {
        // Logique pour créer un membre du personnel
        Staff::create($request->validated());

        return redirect()->route('hopital.staff.index')
                         ->with('success', 'Membre du personnel enregistré avec succès.');
    }

    /**
     * Show the specified staff member.
     * Affiche les détails d'un membre du personnel.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        // Logique pour trouver le membre du personnel
        $staffMember = Staff::findOrFail($id);
        return view('hopital::staff.show', compact('staffMember'));
    }

    /**
     * Show the form for editing the specified staff member.
     * Affiche le formulaire d'édition d'un membre du personnel.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        // Logique pour trouver le membre du personnel à éditer
        $staffMember = Staff::findOrFail($id);
        return view('hopital::staff.edit', compact('staffMember'));
    }

    /**
     * Update the specified staff member in storage.
     * Met à jour les informations d'un membre du personnel.
     * @param UpdateStaffRequest $request
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateStaffRequest $request, $id)
    {
        // Logique pour trouver et mettre à jour le membre du personnel
        $staffMember = Staff::findOrFail($id);
        $staffMember->update($request->validated());

        return redirect()->route('hopital.staff.show', $id)
                         ->with('success', 'Informations du personnel mises à jour avec succès.');
    }

    /**
     * Remove the specified staff member from storage.
     * Supprime un membre du personnel.
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        // Logique pour trouver et supprimer le membre du personnel
        $staffMember = Staff::findOrFail($id);
        $staffMember->delete();

        return redirect()->route('hopital.staff.index')
                         ->with('success', 'Membre du personnel supprimé avec succès.');
    }

    // Méthodes spécifiques
    // public function assignToPatient($staff_id, $patient_id) { ... } // Affecter du personnel à un patient
}