<?php

namespace Modules\Hopital\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\StaffSchedule;
use Modules\Hopital\Entities\Staff; // Assurez-vous d'avoir le modèle Staff
use Modules\Hopital\Http\Requests\StoreStaffScheduleRequest; // À créer
use Modules\Hopital\Http\Requests\UpdateStaffScheduleRequest; // À créer

class StaffScheduleController extends Controller
{
    /**
     * Display a listing of staff schedules.
     * Affiche les plannings du personnel.
     * @return Renderable
     */
    public function index()
    {
        // Logique pour récupérer et afficher les plannings (peut filtrer par date, par staff, etc.)
        $schedules = StaffSchedule::with('staff')->get(); // Exemple
        return view('hopital::staff.schedules.index', compact('schedules'));
    }

    /**
     * Show the form for creating a new staff schedule.
     * Affiche le formulaire de création d'un nouveau planning.
     * @return Renderable
     */
    public function create()
    {
        // Logique pour récupérer la liste du personnel
        $staff = Staff::all();
        return view('hopital::staff.schedules.create', compact('staff'));
    }

    /**
     * Store a newly created staff schedule in storage.
     * Enregistre un nouveau planning.
     * @param StoreStaffScheduleRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreStaffScheduleRequest $request)
    {
        // Logique pour créer un planning
        StaffSchedule::create($request->validated());

        return redirect()->route('hopital.staff.schedules.index')
                         ->with('success', 'Planning créé avec succès.');
    }

    /**
     * Show the specified staff schedule.
     * Affiche les détails d'un planning.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        // Logique pour trouver le planning
        $schedule = StaffSchedule::with('staff')->findOrFail($id);
        return view('hopital::staff.schedules.show', compact('schedule'));
    }

    /**
     * Show the form for editing the specified staff schedule.
     * Affiche le formulaire d'édition d'un planning.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        // Logique pour trouver le planning à éditer et la liste du personnel
        $schedule = StaffSchedule::findOrFail($id);
        $staff = Staff::all();
        return view('hopital::staff.schedules.edit', compact('schedule', 'staff'));
    }

    /**
     * Update the specified staff schedule in storage.
     * Met à jour un planning.
     * @param UpdateStaffScheduleRequest $request
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateStaffScheduleRequest $request, $id)
    {
        // Logique pour trouver et mettre à jour le planning
        $schedule = StaffSchedule::findOrFail($id);
        $schedule->update($request->validated());

        return redirect()->route('hopital.staff.schedules.show', $id)
                         ->with('success', 'Planning mis à jour avec succès.');
    }

    /**
     * Remove the specified staff schedule from storage.
     * Supprime un planning.
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        // Logique pour trouver et supprimer le planning
        $schedule = StaffSchedule::findOrFail($id);
        $schedule->delete();

        return redirect()->route('hopital.staff.schedules.index')
                         ->with('success', 'Planning supprimé avec succès.');
    }
}