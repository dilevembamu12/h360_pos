<?php

namespace Modules\Hopital\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\Appointment;
use Modules\Hopital\Entities\Patient; // Assurez-vous d'avoir les modèles nécessaires
use Modules\Hopital\Entities\Staff;
use Modules\Hopital\Http\Requests\StoreAppointmentRequest; // À créer
use Modules\Hopital\Http\Requests\UpdateAppointmentRequest; // À créer

class AppointmentController extends Controller
{
    /**
     * Display a listing of appointments.
     * Affiche la liste des rendez-vous.
     * @return Renderable
     */
    public function index()
    {
        // Logique pour récupérer et afficher les rendez-vous
        $appointments = Appointment::with(['patient', 'doctor'])->get(); // Exemple
        return view('hopital::appointments.index', compact('appointments'));
    }
    public function create22()
    {
        // Logique pour récupérer les listes de patients et médecins pour le formulaire
        $patients = Patient::all();
        $doctors = Staff::where('role', 'doctor')->get(); // Exemple
        return view('hopital::appointments.create', compact('patients', 'doctors'));
    }


    /**
     * Show the form for creating a new appointment.
     * Affiche le formulaire de création d'un nouveau rendez-vous.
     * @return Renderable
     */
    public function create()
    {
        // Logique pour récupérer les listes de patients et médecins pour le formulaire
        $patients = Patient::all();
        $doctors = Staff::where('role', 'doctor')->get(); // Exemple
        return view('hopital::appointments.create', compact('patients', 'doctors'));
    }

    /**
     * Store a newly created appointment in storage.
     * Enregistre un nouveau rendez-vous.
     * @param StoreAppointmentRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreAppointmentRequest $request)
    {
        // Logique pour créer un rendez-vous
        Appointment::create($request->validated());

        // Logique pour envoyer des rappels (SMS/Email) - pourrait être géré par un job/événement
        // dispatch(new SendAppointmentReminder($appointment)); // Exemple

        return redirect()->route('hopital.appointments.index')
                         ->with('success', 'Rendez-vous créé avec succès.');
    }

    /**
     * Show the specified appointment.
     * Affiche les détails d'un rendez-vous.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        // Logique pour trouver le rendez-vous et ses détails
        $appointment = Appointment::with(['patient', 'doctor'])->findOrFail($id);
        return view('hopital::appointments.show', compact('appointment'));
    }

    /**
     * Show the form for editing the specified appointment.
     * Affiche le formulaire d'édition d'un rendez-vous.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        // Logique pour trouver le rendez-vous à éditer et les listes pour le formulaire
        $appointment = Appointment::findOrFail($id);
        $patients = Patient::all();
        $doctors = Staff::where('role', 'doctor')->get();
        return view('hopital::appointments.edit', compact('appointment', 'patients', 'doctors'));
    }

    /**
     * Update the specified appointment in storage.
     * Met à jour un rendez-vous.
     * @param UpdateAppointmentRequest $request
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateAppointmentRequest $request, $id)
    {
        // Logique pour trouver le rendez-vous et le mettre à jour
        $appointment = Appointment::findOrFail($id);
        $appointment->update($request->validated());

        // Logique pour notifier le patient si le rendez-vous a changé
        // dispatch(new NotifyAppointmentChange($appointment)); // Exemple

        return redirect()->route('hopital.appointments.show', $id)
                         ->with('success', 'Rendez-vous mis à jour avec succès.');
    }

    /**
     * Remove the specified appointment from storage.
     * Supprime un rendez-vous.
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        // Logique pour trouver et supprimer le rendez-vous
        $appointment = Appointment::findOrFail($id);
        $appointment->delete();

        // Logique pour notifier l'annulation
        // dispatch(new NotifyAppointmentCancellation($appointment)); // Exemple

        return redirect()->route('hopital.appointments.index')
                         ->with('success', 'Rendez-vous supprimé avec succès.');
    }

    // Méthodes spécifiques
    /**
     * Send reminder for a specific appointment.
     * Envoie un rappel pour un rendez-vous (pourrait être manuel ou déclenché par un cron).
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function sendReminder($id)
    {
         $appointment = Appointment::findOrFail($id);
         // Logique pour envoyer le rappel (SMS, email, etc.)
         // dispatch(new SendAppointmentReminder($appointment)); // Exemple

         return back()->with('success', 'Rappel envoyé pour le rendez-vous.');
    }
}