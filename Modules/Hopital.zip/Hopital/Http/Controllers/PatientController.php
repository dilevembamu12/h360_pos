<?php

namespace Modules\Hopital\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\Patient;
use Modules\Hopital\Http\Requests\StorePatientRequest; // À créer
use Modules\Hopital\Http\Requests\UpdatePatientRequest; // À créer

class PatientController extends Controller
{
    /**
     * Display a listing of the resource.
     * Affiche la liste des patients.
     * @return Renderable
     */
    public function index()
    {
        // Logique pour récupérer et afficher la liste des patients
        $patients = Patient::all(); // Exemple
        return view('hopital::patients.index', compact('patients'));
    }

    /**
     * Show the form for creating a new resource.
     * Affiche le formulaire de création d'un nouveau patient.
     * @return Renderable
     */
    public function create()
    {
        return view('hopital::patients.create');
    }

    /**
     * Store a newly created resource in storage.
     * Enregistre un nouveau patient dans la base de données.
     * @param StorePatientRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StorePatientRequest $request)
    {
        // Logique pour créer un patient avec les données validées
        Patient::create($request->validated());

        return redirect()->route('hopital.patients.index')
                         ->with('success', 'Patient enregistré avec succès.');
    }

    /**
     * Show the specified resource.
     * Affiche les détails d'un patient spécifique, incluant sa fiche de traitement.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        // Logique pour trouver le patient et charger ses relations (historique, allergies, etc.)
        $patient = Patient::with(['medicalHistory', 'allergies', 'medications', 'appointments'])->findOrFail($id);
        return view('hopital::patients.show', compact('patient'));
    }

    /**
     * Show the form for editing the specified resource.
     * Affiche le formulaire d'édition d'un patient.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        // Logique pour trouver le patient à éditer
        $patient = Patient::findOrFail($id);
        return view('hopital::patients.edit', compact('patient'));
    }

    /**
     * Update the specified resource in storage.
     * Met à jour les informations d'un patient dans la base de données.
     * @param UpdatePatientRequest $request
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdatePatientRequest $request, $id)
    {
        // Logique pour trouver le patient et mettre à jour avec les données validées
        $patient = Patient::findOrFail($id);
        $patient->update($request->validated());

        return redirect()->route('hopital.patients.show', $id)
                         ->with('success', 'Informations du patient mises à jour avec succès.');
    }

    /**
     * Remove the specified resource from storage.
     * Supprime un patient de la base de données.
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        // Logique pour trouver et supprimer le patient
        $patient = Patient::findOrFail($id);
        $patient->delete();

        return redirect()->route('hopital.patients.index')
                         ->with('success', 'Patient supprimé avec succès.');
    }

    // Méthodes spécifiques au scénario pourraient être ajoutées ici, par ex:
    // public function registerInpatient($id) { ... } // Enregistrer un patient comme hospitalisé
    // public function registerAmbulatory($id) { ... } // Enregistrer un patient comme ambulatoire
}