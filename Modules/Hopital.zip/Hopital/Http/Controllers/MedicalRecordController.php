<?php

namespace Modules\Hopital\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\Patient; // Assurez-vous d'avoir le modèle Patient
// Inclure d'autres modèles pertinents pour le dossier médical
// use Modules\Hopital\Entities\Prescription;
// use Modules\Hopital\Entities\LabResult;
// use Modules\Hopital\Entities\PatientMedicalHistory;

class MedicalRecordController extends Controller
{
    /**
     * Display the medical record for a specific patient.
     * Affiche le dossier médical complet d'un patient.
     * @param int $patient_id
     * @return Renderable
     */
    public function show($patient_id)
    {
        // Logique pour trouver le patient et charger toutes les relations pertinentes pour le dossier médical
        $patient = Patient::with([
            'medicalHistory',
            'allergies',
            'medications',
            'appointments.prescriptions', // Si les prescriptions sont liées aux rendez-vous
            'examOrders.labResult', // Si les examens sont liés aux commandes d'examen
            // Ajoutez d'autres relations nécessaires (opérations, vaccinations, etc.)
        ])->findOrFail($patient_id);

        return view('hopital::medical_records.show', compact('patient'));
    }

    // Des méthodes pour ajouter/éditer des éléments spécifiques pourraient être ici,
    // ou plus probablement dans des contrôleurs dédiés (ex: PrescriptionController@store)
    // public function addPrescription(Request $request, $patient_id) { ... }
}