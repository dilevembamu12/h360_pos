<?php

namespace Modules\Hopital\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\ExamOrder;
use Modules\Hopital\Entities\LabResult;
use Modules\Hopital\Entities\Patient; // Assurez-vous d'avoir le modèle Patient
use Modules\Hopital\Entities\Staff; // Pour les médecins qui commandent
use Modules\Hopital\Entities\Exam; // Modèle pour les types d'examens (Bio, Radio, etc.)
use Modules\Hopital\Http\Requests\StoreExamOrderRequest; // À créer
use Modules\Hopital\Http\Requests\StoreLabResultRequest; // À créer

class LabController extends Controller
{
    /**
     * Display a listing of exam orders.
     * Affiche la liste des commandes d'examens.
     * @return Renderable
     */
    public function indexOrders()
    {
        // Logique pour récupérer et afficher les commandes d'examens (souvent celles en attente)
        $examOrders = ExamOrder::with(['patient', 'exam'])->where('status', '!=', 'completed')->get(); // Exemple
        return view('hopital::lab.orders.index', compact('examOrders'));
    }

    /**
     * Display a listing of lab results.
     * Affiche la liste des résultats de laboratoire.
     * @return Renderable
     */
    public function indexResults()
    {
         // Logique pour récupérer et afficher les résultats
        $labResults = LabResult::with(['examOrder.patient', 'examOrder.exam'])->get(); // Exemple
        return view('hopital::lab.results.index', compact('labResults'));
    }


    /**
     * Show the form for creating a new exam order.
     * Affiche le formulaire pour commander un examen.
     * @return Renderable
     */
    public function createOrder()
    {
        // Logique pour récupérer les patients et les types d'examens
        $patients = Patient::all();
        $exams = Exam::all(); // Exemple
        $doctors = Staff::where('role', 'doctor')->get(); // Exemple
        return view('hopital::lab.orders.create', compact('patients', 'exams', 'doctors'));
    }

    /**
     * Store a newly created exam order in storage.
     * Enregistre une nouvelle commande d'examen.
     * @param StoreExamOrderRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function storeOrder(StoreExamOrderRequest $request)
    {
        // Logique pour créer une commande d'examen
        ExamOrder::create($request->validated());

        return redirect()->route('hopital.lab.orders.index')
                         ->with('success', 'Commande d\'examen enregistrée avec succès.');
    }

    /**
     * Show the specified exam order.
     * Affiche les détails d'une commande d'examen.
     * @param int $id
     * @return Renderable
     */
    public function showOrder($id)
    {
        // Logique pour trouver la commande
        $examOrder = ExamOrder::with(['patient', 'exam', 'labResult'])->findOrFail($id);
        return view('hopital::lab.orders.show', compact('examOrder'));
    }

    // Pas forcément besoin d'edit/update pour les commandes d'examen une fois créées,
    // mais on pourrait avoir une méthode pour annuler.

    /**
     * Remove the specified exam order from storage.
     * Annule une commande d'examen.
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function cancelOrder($id) // Renommé de destroy
    {
        // Logique pour trouver et annuler la commande (ne pas forcément supprimer)
        $examOrder = ExamOrder::findOrFail($id);
        $examOrder->status = 'cancelled'; // Exemple de statut
        $examOrder->save();

        return redirect()->route('hopital.lab.orders.index')
                         ->with('success', 'Commande d\'examen annulée.');
    }

    /**
     * Show the form for uploading/entering lab results for an order.
     * Affiche le formulaire pour ajouter les résultats d'une commande.
     * @param int $order_id
     * @return Renderable
     */
    public function createResult($order_id)
    {
        // Logique pour trouver la commande et préparer le formulaire
        $examOrder = ExamOrder::with(['patient', 'exam'])->findOrFail($order_id);
        // Vérifier si un résultat existe déjà
        if ($examOrder->labResult) {
             return redirect()->route('hopital.lab.results.show', $examOrder->labResult->id)
                              ->with('info', 'Un résultat existe déjà pour cette commande.');
        }
        return view('hopital::lab.results.create', compact('examOrder'));
    }

    /**
     * Store lab results for a specific order.
     * Enregistre les résultats d'une commande.
     * @param StoreLabResultRequest $request
     * @param int $order_id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function storeResult(StoreLabResultRequest $request, $order_id)
    {
        // Logique pour trouver la commande et enregistrer le résultat
        $examOrder = ExamOrder::findOrFail($order_id);

        // Vérifier si un résultat existe déjà pour cette commande
         if ($examOrder->labResult) {
              return back()->withErrors(['result_exists' => 'Un résultat existe déjà pour cette commande.'])
                           ->withInput();
         }

        $resultData = $request->validated();
        $resultData['exam_order_id'] = $order_id;
        // Gérer le téléchargement de fichiers si nécessaire
        // if ($request->hasFile('file')) { ... }

        $labResult = LabResult::create($resultData);

        // Mettre à jour le statut de la commande
        $examOrder->status = 'completed';
        $examOrder->save();

        // Notifier le médecin/patient que les résultats sont prêts (pourrait être un job/événement)
        // dispatch(new LabResultReady($labResult)); // Exemple

        return redirect()->route('hopital.lab.results.show', $labResult->id)
                         ->with('success', 'Résultats enregistrés et liés à la commande.');
    }

     /**
     * Show the specified lab result.
     * Affiche les détails d'un résultat de laboratoire.
     * @param int $id
     * @return Renderable
     */
    public function showResult($id)
    {
        // Logique pour trouver le résultat et ses détails
        $labResult = LabResult::with(['examOrder.patient', 'examOrder.exam'])->findOrFail($id);
        return view('hopital::lab.results.show', compact('labResult'));
    }

     /**
     * Show the form for editing the specified lab result.
     * Affiche le formulaire d'édition d'un résultat.
     * @param int $id
     * @return Renderable
     */
    public function editResult($id)
    {
        // Logique pour trouver le résultat à éditer
        $labResult = LabResult::with(['examOrder.patient', 'examOrder.exam'])->findOrFail($id);
         return view('hopital::lab.results.edit', compact('labResult'));
    }

     /**
     * Update the specified lab result in storage.
     * Met à jour un résultat de laboratoire.
     * @param Request $request // Utiliser UpdateLabResultRequest à créer
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateResult(Request $request, $id) // Remplacer Request par UpdateLabResultRequest
    {
        // Logique pour trouver et mettre à jour le résultat
        $labResult = LabResult::findOrFail($id);
         // $labResult->update($request->validated()); // Utiliser la validation

        // Gérer la mise à jour du fichier si applicable

        return redirect()->route('hopital.lab.results.show', $id)
                         ->with('success', 'Résultats mis à jour avec succès.');
    }

    /**
     * Remove the specified lab result from storage.
     * Supprime un résultat de laboratoire.
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroyResult($id)
    {
         // Logique pour trouver et supprimer le résultat
        $labResult = LabResult::findOrFail($id);
        $labResult->delete();

        // Optionnel: Mettre à jour le statut de la commande associée si nécessaire (ex: repasser en 'pending' si pas d'autres résultats)

        return redirect()->route('hopital.lab.results.index')
                         ->with('success', 'Résultat supprimé avec succès.');
    }
}