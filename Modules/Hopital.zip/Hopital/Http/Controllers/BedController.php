<?php

namespace Modules\Hopital\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\Bed;
use Modules\Hopital\Entities\Room; // Modèle pour les chambres
use Modules\Hopital\Http\Requests\StoreBedRequest; // À créer
use Modules\Hopital\Http\Requests\UpdateBedRequest; // À créer
// use Modules\Hopital\Http\Requests\StoreRoomRequest; // À créer si gestion des chambres ici
// use Modules\Hopital\Http\Requests\UpdateRoomRequest; // À créer

class BedController extends Controller
{
    /**
     * Display a listing of beds.
     * Affiche la liste des lits (et chambres).
     * @return Renderable
     */
    public function index()
    {
        // Logique pour récupérer et afficher les lits, groupés par chambre ou avec les détails de la chambre
        $beds = Bed::with('room')->get(); // Exemple
        $rooms = Room::with('beds')->get(); // Exemple pour une vue groupée par chambre
        return view('hopital::beds.index', compact('beds', 'rooms'));
    }

    /**
     * Show the form for creating a new bed.
     * Affiche le formulaire de création d'un nouveau lit.
     * @return Renderable
     */
    public function create()
    {
        // Logique pour récupérer les chambres existantes pour associer le lit
        $rooms = Room::all();
        return view('hopital::beds.create', compact('rooms'));
    }

    /**
     * Store a newly created bed in storage.
     * Enregistre un nouveau lit.
     * @param StoreBedRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreBedRequest $request)
    {
        // Logique pour créer un lit
        Bed::create($request->validated());

        return redirect()->route('hopital.beds.index')
                         ->with('success', 'Lit enregistré avec succès.');
    }

    /**
     * Show the specified bed.
     * Affiche les détails d'un lit.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        // Logique pour trouver le lit et charger les relations (chambre, historique d'occupations)
        $bed = Bed::with(['room', 'hospitalizations.patient'])->findOrFail($id); // Assurez-vous des relations
        return view('hopital::beds.show', compact('bed'));
    }

    /**
     * Show the form for editing the specified bed.
     * Affiche le formulaire d'édition d'un lit.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        // Logique pour trouver le lit à éditer et les chambres
        $bed = Bed::findOrFail($id);
        $rooms = Room::all();
        return view('hopital::beds.edit', compact('bed', 'rooms'));
    }

    /**
     * Update the specified bed in storage.
     * Met à jour les informations d'un lit.
     * @param UpdateBedRequest $request
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateBedRequest $request, $id)
    {
        // Logique pour trouver et mettre à jour le lit
        $bed = Bed::findOrFail($id);
        $bed->update($request->validated());

        return redirect()->route('hopital.beds.show', $id)
                         ->with('success', 'Informations du lit mises à jour avec succès.');
    }

    /**
     * Remove the specified bed from storage.
     * Supprime un lit (attention si associé à des hospitalisations).
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        // Logique pour trouver et supprimer le lit
        $bed = Bed::findOrFail($id);

        // Vérifiez les dépendances avant de supprimer (hospitalisations actives)
        if ($bed->hospitalizations()->whereNull('discharge_date')->exists()) {
            return back()->withErrors('Impossible de supprimer un lit occupé.');
        }

        $bed->delete();

        return redirect()->route('hopital.beds.index')
                         ->with('success', 'Lit supprimé avec succès.');
    }

    // Méthodes pour la gestion des chambres si elles ne sont pas dans un autre contrôleur (ex: RoomController)
    /**
     * Display a listing of rooms.
     * Affiche la liste des chambres.
     * @return Renderable
     */
    public function indexRooms() // Si les chambres sont gérées ici
    {
         $rooms = Room::with('beds')->get();
         return view('hopital::beds.rooms.index', compact('rooms'));
    }

    /**
     * Show the form for creating a new room.
     * Affiche le formulaire de création d'une chambre.
     * @return Renderable
     */
    public function createRoom() // Si les chambres sont gérées ici
    {
         return view('hopital::beds.rooms.create');
    }

     /**
     * Store a newly created room in storage.
     * Enregistre une nouvelle chambre.
     * @param StoreRoomRequest $request // À créer
     * @return \Illuminate\Http\RedirectResponse
     */
    public function storeRoom(Request $request) // Remplacer Request par StoreRoomRequest
    {
        // Logique pour créer une chambre
        // Room::create($request->validated());
        // return redirect()->route('hopital.beds.index.rooms')->with('success', 'Chambre créée.');
        // Placeholder
    }
}