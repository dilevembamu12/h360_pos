<?php

namespace Modules\Hopital\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\InsuranceClaim;
use Modules\Hopital\Entities\Bill; // Les demandes sont souvent liées à une facture
use Modules\Hopital\Entities\InsuranceProvider; // Modèle pour les compagnies d'assurance
use Modules\Hopital\Http\Requests\StoreInsuranceClaimRequest; // À créer
use Modules\Hopital\Http\Requests\UpdateInsuranceClaimRequest; // À créer

class InsuranceClaimController extends Controller
{
    /**
     * Display a listing of insurance claims.
     * Affiche la liste des demandes d'indemnisation.
     * @return Renderable
     */
    public function index()
    {
        // Logique pour récupérer et afficher les demandes
        $claims = InsuranceClaim::with(['bill.patient', 'insuranceProvider'])->get(); // Exemple
        return view('hopital::billing.insurance.index', compact('claims'));
    }

    /**
     * Show the form for creating a new insurance claim.
     * Affiche le formulaire de création d'une nouvelle demande.
     * @return Renderable
     */
    public function create()
    {
        // Logique pour récupérer les factures en attente d'indemnisation et les assureurs
        $bills = Bill::where('status', 'pending_insurance')->get(); // Exemple de filtre
        $insuranceProviders = InsuranceProvider::all(); // Exemple
        return view('hopital::billing.insurance.create', compact('bills', 'insuranceProviders'));
    }

    /**
     * Store a newly created insurance claim in storage.
     * Enregistre une nouvelle demande d'indemnisation.
     * @param StoreInsuranceClaimRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreInsuranceClaimRequest $request)
    {
        // Logique pour créer une demande
        $claim = InsuranceClaim::create($request->validated());

        // Mettre à jour le statut de la facture associée si nécessaire
        // $claim->bill->status = 'claimed';
        // $claim->bill->save();

        return redirect()->route('hopital.insurance.claims.show', $claim->id)
                         ->with('success', 'Demande d\'indemnisation enregistrée avec succès.');
    }

    /**
     * Show the specified insurance claim.
     * Affiche les détails d'une demande.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        // Logique pour trouver la demande et charger ses détails
        $claim = InsuranceClaim::with(['bill.patient', 'insuranceProvider'])->findOrFail($id);
        return view('hopital::billing.insurance.show', compact('claim'));
    }

    /**
     * Show the form for editing the specified insurance claim.
     * Affiche le formulaire d'édition d'une demande.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        // Logique pour trouver la demande à éditer et les listes pour le formulaire
        $claim = InsuranceClaim::findOrFail($id);
        $bills = Bill::where('status', 'pending_insurance')->orWhere('id', $claim->bill_id)->get(); // Inclure la facture actuelle
        $insuranceProviders = InsuranceProvider::all();
        return view('hopital::billing.insurance.edit', compact('claim', 'bills', 'insuranceProviders'));
    }

    /**
     * Update the specified insurance claim in storage.
     * Met à jour une demande d'indemnisation.
     * @param UpdateInsuranceClaimRequest $request
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateInsuranceClaimRequest $request, $id)
    {
        // Logique pour trouver et mettre à jour la demande
        $claim = InsuranceClaim::findOrFail($id);
        $claim->update($request->validated());

        // Mettre à jour le statut de la facture si le statut de la demande change
        // if ($request->has('status')) {
        //     if ($request->status == 'approved') {
        //          $claim->bill->status = 'insurance_paid';
        //     } elseif ($request->status == 'rejected') {
        //          $claim->bill->status = 'pending_patient_payment';
        //     }
        //     $claim->bill->save();
        // }


        return redirect()->route('hopital.insurance.claims.show', $id)
                         ->with('success', 'Demande d\'indemnisation mise à jour avec succès.');
    }

    /**
     * Remove the specified insurance claim from storage.
     * Supprime une demande d'indemnisation.
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        // Logique pour trouver et supprimer la demande
        $claim = InsuranceClaim::findOrFail($id);

        // Réinitialiser le statut de la facture associée si nécessaire
        // $bill = $claim->bill;
        $claim->delete();
        // if ($bill) {
        //     $bill->status = 'pending_insurance'; // Ou un autre statut approprié
        //     $bill->save();
        // }


        return redirect()->route('hopital.insurance.claims.index')
                         ->with('success', 'Demande d\'indemnisation supprimée avec succès.');
    }

    // Méthodes spécifiques
    /**
     * Mark a claim as submitted to the insurance provider.
     * Marque une demande comme soumise.
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function markAsSubmitted($id)
    {
        // $claim = InsuranceClaim::findOrFail($id);
        // $claim->status = 'submitted';
        // $claim->submission_date = now();
        // $claim->save();
        // return back()->with('success', 'Demande marquée comme soumise.');
        // Placeholder
    }

    /**
     * Mark a claim as approved or rejected.
     * Marque une demande comme approuvée ou rejetée.
     * @param Request $request // Inclure le statut (approved/rejected) et le montant approuvé si applicable
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateStatus(Request $request, $id)
    {
        // $claim = InsuranceClaim::findOrFail($id);
        // $claim->status = $request->status; // 'approved' or 'rejected'
        // if ($request->status == 'approved') {
        //     $claim->approved_amount = $request->approved_amount;
        //     // Gérer la portion restante pour le patient si applicable
        // }
        // $claim->save();
        // // Mettre à jour le statut de la facture associée
        // return back()->with('success', 'Statut de la demande mis à jour.');
        // Placeholder
    }
}