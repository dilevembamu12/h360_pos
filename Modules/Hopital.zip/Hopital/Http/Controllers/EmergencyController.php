<?php

namespace Modules\Hopital\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\Emergency; // Modèle pour les alertes d'urgence
use Modules\Hopital\Entities\Patient; // Assurez-vous d'avoir le modèle Patient
// use Modules\Hopital\Events\EmergencyAlertTriggered; // Événement à déclencher

class EmergencyController extends Controller
{
    /**
     * Display a listing of emergency alerts.
     * Affiche la liste des alertes d'urgence.
     * @return Renderable
     */
    public function index()
    {
        // Logique pour récupérer et afficher les alertes (actives ou historiques)
        $emergencies = Emergency::with('patient')->orderBy('created_at', 'desc')->get(); // Exemple
        return view('hopital::emergencies.index', compact('emergencies'));
    }

    /**
     * Show the form for triggering a new emergency alert.
     * Affiche le formulaire pour déclencher une nouvelle alerte.
     * @return Renderable
     */
    public function create()
    {
        // Logique pour récupérer la liste des patients (si l'alerte est liée à un patient)
        $patients = Patient::all();
        return view('hopital::emergencies.create', compact('patients'));
    }

    /**
     * Store a newly created emergency alert.
     * Déclenche une nouvelle alerte d'urgence.
     * @param Request $request // À créer si validation spécifique nécessaire
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        // Logique pour créer l'alerte d'urgence
        $validatedData = $request->validate([
            'patient_id' => 'nullable|exists:hopital_patients,id', // Assurez-vous du nom de la table
            'type' => 'required|string', // Ex: 'Cardiac Arrest', 'Fire', etc.
            'location' => 'nullable|string', // Ex: 'Chambre 301', 'Urgence', etc.
            'details' => 'nullable|string',
        ]);

        $emergency = Emergency::create($validatedData);

        // Déclencher un événement pour notifier le personnel, activer des systèmes, etc.
        // event(new EmergencyAlertTriggered($emergency)); // Exemple

        return redirect()->route('hopital.emergencies.index')
                         ->with('success', 'Alerte d\'urgence déclenchée !');
    }

    /**
     * Show the specified emergency alert.
     * Affiche les détails d'une alerte d'urgence, et potentiellement les informations critiques du patient.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        // Logique pour trouver l'alerte et charger les infos patient si applicable
        $emergency = Emergency::with('patient.criticalInfo')->findOrFail($id); // Assurez-vous de la relation criticalInfo
        return view('hopital::emergencies.show', compact('emergency'));
    }

    /**
     * Mark an emergency alert as resolved.
     * Marque une alerte d'urgence comme résolue.
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function resolve($id) // Méthode spécifique
    {
        // Logique pour trouver l'alerte et la marquer comme résolue
        $emergency = Emergency::findOrFail($id);
        $emergency->status = 'resolved'; // Exemple de statut
        $emergency->resolved_at = now();
        // $emergency->resolved_by_staff_id = auth()->id(); // Si vous suivez qui résout
        $emergency->save();

        // Optionnel: Notifier que l'urgence est terminée

        return back()->with('success', 'Alerte d\'urgence marquée comme résolue.');
    }

    // Pas de méthodes edit/update/destroy classiques pour les alertes d'urgence,
    // mais plutôt une méthode pour les résoudre.
}