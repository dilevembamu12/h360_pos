<?php

namespace Modules\Hopital\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\Hospitalization; // Modèle pour l'enregistrement de l'hospitalisation
use Modules\Hopital\Entities\Patient; // Assurez-vous d'avoir le modèle Patient
use Modules\Hopital\Entities\Bed; // Assurez-vous d'avoir le modèle Bed
// use Modules\Hopital\Entities\DailyCareLog; // Modèle pour le suivi des soins quotidiens
use Modules\Hopital\Http\Requests\StoreHospitalizationRequest; // À créer
// use Modules\Hopital\Http\Requests\UpdateHospitalizationRequest; // À créer
// use Modules\Hopital\Http\Requests\LogDailyCareRequest; // À créer

class InpatientController extends Controller
{
    /**
     * Display a listing of hospitalized patients.
     * Affiche la liste des patients hospitalisés.
     * @return Renderable
     */
    public function index()
    {
        // Logique pour récupérer et afficher les hospitalisations actives
        $hospitalizations = Hospitalization::with(['patient', 'bed.room'])->whereNull('discharge_date')->get(); // Exemple
        return view('hopital::inpatients.index', compact('hospitalizations'));
    }

    /**
     * Display a listing of hospitalized patients.
     * Affiche la liste des patients hospitalisés.
     * @return Renderable
     */
    public function show()
    {
        // Logique pour récupérer et afficher les hospitalisations actives
        $hospitalizations = Hospitalization::with(['patient', 'bed.room'])->whereNull('discharge_date')->get(); // Exemple
        return view('hopital::inpatients.index', compact('hospitalizations'));
    }

    /**
     * Show the form for admitting a new patient for hospitalization.
     * Affiche le formulaire d'admission pour un patient hospitalisé.
     * @return Renderable
     */
    public function createAdmission()
    {
        // Logique pour récupérer les patients non hospitalisés et les lits disponibles
        $patients = Patient::whereDoesntHave('activeHospitalization')->get(); // Exemple de scope sur le modèle Patient
        $availableBeds = Bed::where('status', 'available')->with('room')->get(); // Exemple
        return view('hopital::inpatients.admit', compact('patients', 'availableBeds'));
    }

    /**
     * Store a new hospitalization record.
     * Enregistre l'admission d'un patient.
     * @param StoreHospitalizationRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function storeAdmission(StoreHospitalizationRequest $request)
    {
        // Logique pour créer l'enregistrement d'hospitalisation
        $hospitalization = Hospitalization::create($request->validated());

        // Mettre à jour le statut du lit
        $bed = Bed::findOrFail($request->bed_id);
        $bed->status = 'occupied';
        $bed->save();

        // Commencer la facturation journalière (pourrait être déclenché par un événement/job)

        return redirect()->route('hopital.inpatients.show', $hospitalization->id)
                         ->with('success', 'Patient admis avec succès.');
    }

    /**
     * Show the specified hospitalization record (patient details + hospitalization info).
     * Affiche les détails d'une hospitalisation active.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        // Logique pour trouver l'enregistrement d'hospitalisation et charger les relations
        $hospitalization = Hospitalization::with(['patient', 'bed.room', 'dailyCareLogs', 'bills'])->findOrFail($id); // Assurez-vous des relations
        return view('hopital::inpatients.show', compact('hospitalization'));
    }

    // Pas forcément besoin d'edit/update direct sur l'hospitalisation principale,
    // mais on peut avoir des méthodes pour ajouter des soins, des visites, etc.

    /**
     * Show the form for discharging a patient.
     * Affiche le formulaire de sortie pour un patient.
     * @param int $id // ID de l'enregistrement d'hospitalisation
     * @return Renderable
     */
    public function createDischarge($id)
    {
        // Logique pour trouver l'hospitalisation et préparer le formulaire de sortie
        $hospitalization = Hospitalization::with(['patient', 'bed'])->findOrFail($id);
        if ($hospitalization->discharge_date) {
            return redirect()->route('hopital.inpatients.show', $id)
                             ->with('info', 'Ce patient a déjà été déchargé.');
        }
        // Récupérer les factures en attente ou à finaliser
        $pendingBills = $hospitalization->bills()->where('status', '!=', 'paid')->get(); // Exemple

        return view('hopital::inpatients.discharge', compact('hospitalization', 'pendingBills'));
    }

    /**
     * Process the discharge of a patient.
     * Enregistre la sortie d'un patient.
     * @param Request $request // Pour les détails de sortie, paiement final, etc.
     * @param int $id // ID de l'enregistrement d'hospitalisation
     * @return \Illuminate\Http\RedirectResponse
     */
    public function storeDischarge(Request $request, $id)
    {
        // Logique pour trouver l'hospitalisation et enregistrer la sortie
        $hospitalization = Hospitalization::with('bed')->findOrFail($id);

        // Mettre à jour la date de sortie
        $hospitalization->discharge_date = now(); // Ou $request->discharge_date;
        $hospitalization->discharge_summary = $request->discharge_summary; // Exemple
        $hospitalization->follow_up_instructions = $request->follow_up_instructions; // Exemple
        $hospitalization->save();

        // Mettre à jour le statut du lit
        $bed = $hospitalization->bed;
        if ($bed) {
             $bed->status = 'available'; // Ou 'needs_cleaning'
             $bed->save();
        }


        // Finaliser la facturation (calculer les frais restants, etc.)
        // Logique de facturation finale ici ou appel à un service de facturation

        // Gérer le paiement final si applicable
        // if ($request->has('final_payment')) { ... }

        return redirect()->route('hopital.inpatients.index') // Rediriger vers la liste des hospitalisations passées ou tous les patients
                         ->with('success', 'Patient déchargé avec succès.');
    }

    // Méthodes spécifiques
    /**
     * Add a daily care log entry for a patient.
     * Ajoute un événement de soin quotidien pour un patient hospitalisé.
     * @param LogDailyCareRequest $request // À créer
     * @param int $hospitalization_id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function logDailyCare(Request $request, $hospitalization_id) // Remplacer Request par LogDailyCareRequest
    {
        // $hospitalization = Hospitalization::findOrFail($hospitalization_id);
        // $hospitalization->dailyCareLogs()->create($request->validated());
        // return back()->with('success', 'Soin quotidien enregistré.');
        // Placeholder
    }
}