<?php

namespace Modules\Hopital\Http\Controllers;

use App\User; // Supposons que les utilisateurs du système (staff médical, admin) soient dans le modèle User principal
use App\Business; // Supposons que les informations de l'établissement soient dans le modèle Business principal
use App\Utils\ModuleUtil; // Utilitaire pour les modules, si présent dans l'app principale
use App\Utils\Util; // Utilitaires généraux, si présent dans l'app principale
use Illuminate\Routing\Controller;
use Nwidart\Menus\Facades\Menu; // Pour l'intégration des menus
use Modules\Hopital\Entities\Appointment; // Exemple d'entité pour les hooks calendrier
use Modules\Hopital\Entities\Hospitalization; // Exemple d'entité pour les hooks
use Modules\Hopital\Entities\Patient; // Exemple d'entité pour les hooks patient
// N'oubliez pas d'importer d'autres modèles/utilitaires si nécessaire pour les méthodes ajoutées

class DataController extends Controller
{
    /**
     * Fournit la configuration pour les éléments de menu du module
     * qui doivent être ajoutés au menu principal de l'application (sidebar).
     *
     * Cette méthode utilise la façade Menu pour ajouter ou modifier le menu.
     * Inspiré de la méthode modifyAdminMenu du module CRM.
     *
     * @return void
     */
    public function modifyAdminMenu()
    {
        // Récupérer l'ID de l'établissement courant si nécessaire pour les permissions
        $business_id = session()->get('user.business_id');
        $module_util = new ModuleUtil(); // Assurez-vous que cette classe utilitaire existe

        // Vérifier si le module Hôpital est activé pour cet établissement (logique potentielle)
        $is_hopital_enabled = (bool) $module_util->hasThePermissionInSubscription($business_id, 'hopital_module'); // Remplacer 'hopital_module' par le nom de la permission/fonctionnalité

         // Vérifier si l'utilisateur a la permission d'accéder au module Hôpital
         $can_access_hopital = auth()->user()->can('hopital.access_module'); // Assurez-vous que cette permission est définie

         dd($is_hopital_enabled ."&&". $can_access_hopital);
        if ($is_hopital_enabled && $can_access_hopital) {
            // Accéder au menu principal (le nom 'admin-sidebar-menu' est un exemple basé sur le CRM)
            if (Menu::exists('admin-sidebar-menu')) {
                 Menu::modify(
                     'admin-sidebar-menu',
                     function ($menu) {
                        // Ajout de l'élément de menu principal pour l'Hôpital
                        // Utilisez une route nommée pour le tableau de bord du module
                        $menu->url(action([\Modules\Hopital\Http\Controllers\HopitalDashboardController::class, 'index']),
                                   __('hopital::lang.hopital'), // Texte du menu (utiliser un fichier de langue)
                                   ['icon' => 'fas fa-hospital', // Icône Font Awesome (adapter)
                                    'active' => request()->segment(1) == 'hopital' // Marquer actif si URL commence par /hopital
                                    // Ajouter d'autres attributs si nécessaire (style, classes)
                                   ]
                            )->order(90); // Ordre d'affichage (ajuster)

                         // Ajout des sous-menus au menu Hôpital (si le système de menu supporte les enfants)
                         // La méthode exacte pour ajouter des enfants peut varier selon la version/config du package de menu.
                         // Voici un exemple conceptuel ou utilisant une syntaxe courante:
                         // Il faudrait que la méthode `url` ci-dessus retourne l'item de menu créé pour y ajouter des enfants.
                         /*
                         $hopitalMenuItem = $menu->url(...); // Créer l'item et stocker la référence

                         $hopitalMenuItem->add(
                             route('hopital.patients.index'),
                             __('hopital::lang.patients'),
                             ['icon' => 'fas fa-procedures']
                         )->order(10);

                          $hopitalMenuItem->add(
                             route('hopital.appointments.index'),
                             __('hopital::lang.appointments'),
                             ['icon' => 'fas fa-calendar-alt']
                         )->order(20);

                         // etc. pour les autres sous-menus (Personnel, Hospitalisations, Lits, Labo, Facturation, Urgences)
                         */
                         // Alternative si le package le supporte (vérifier la doc de nwidart/laravel-menus) :
                         // $menu->item('hopital_main_menu')->add(...); // Où 'hopital_main_menu' est un ID unique
                         // Voir l'exemple de modifyAdminMenu dans la pensée pour une structure de retour pour les enfants si Menu::modify le gère ainsi.

                          // --- Si le système de menu n'appelle pas cette méthode ou utilise un autre hook,
                          // --- vous pourriez utiliser la méthode Menu::get('sidebar')->add(...) dans le ServiceProvider
                          // --- comme vu précédemment. Cette méthode modifyAdminMenu est spécifiquement pour les systèmes
                          // --- qui appellent une méthode sur un DataController pour modifier un menu existant.

                     }
                 );
            }
        }
    }

    /**
     * Fournit la configuration pour les onglets à afficher sur une vue de patient
     * dans l'application principale.
     *
     * Inspiré de get_contact_view_tabs du module CRM, adapté pour les Patients.
     *
     * @param  \App\Models\Patient $patient L'objet Patient pour lequel afficher les onglets.
     * @return array Un tableau d'onglets, où chaque onglet est un tableau avec
     *               au moins 'title', 'view', et 'data' (optionnel).
     */
    public function get_patient_view_tabs($patient)
    {
        $module_util = new ModuleUtil();
        $business_id = request()->session()->get('user.business_id');
        $is_hopital_enabled = (bool) $module_util->hasThePermissionInSubscription($business_id, 'hopital_module'); // Vérification de l'activation du module
        $can_access_patient_tabs = auth()->user()->can('hopital.patient.view_medical_history'); // Exemple de permission

        if (!$is_hopital_enabled || !$can_access_patient_tabs) {
            return []; // Retourne un tableau vide si le module n'est pas activé ou si l'utilisateur n'a pas la permission
        }

        // Retourne un tableau d'onglets pour la vue détaillée d'un patient.
        // Ces onglets afficheront des informations spécifiques au module Hôpital.
        return [
            [
                'id' => 'patient_medical_history', // ID unique de l'onglet
                'title' => __('hopital::lang.medical_history'), // Titre localisé
                'view' => 'hopital::patients.tabs.medical_history', // Chemin de la vue Blade pour cet onglet
                'data' => [ // Données optionnelles à passer à la vue de l'onglet
                    // Charger les relations ici ou dans la vue de l'onglet selon la complexité
                    'medicalHistory' => $patient->medicalHistory, // Supposons une relation Eloquent `medicalHistory` sur le modèle Patient
                    'allergies' => $patient->allergies, // Supposons une relation Eloquent `allergies`
                    'medications' => $patient->currentMedications, // Supposons une relation Eloquent `currentMedications`
                ],
                 'order' => 10, // Ordre d'affichage des onglets
            ],
             [
                'id' => 'patient_appointments',
                'title' => __('hopital::lang.appointments'),
                'view' => 'hopital::patients.tabs.appointments',
                 'data' => [
                    'appointments' => $patient->appointments, // Supposons une relation `appointments`
                ],
                 'order' => 20,
            ],
             [
                'id' => 'patient_hospitalizations',
                'title' => __('hopital::lang.hospitalizations'),
                'view' => 'hopital::patients.tabs.hospitalizations',
                 'data' => [
                    'hospitalizations' => $patient->hospitalizations()->with(['bed.room', 'admittingStaff'])->get(), // Charger la relation et sous-relations
                ],
                 'order' => 30,
            ],
             [
                'id' => 'patient_lab_results',
                'title' => __('hopital::lang.lab_results'),
                'view' => 'hopital::patients.tabs.lab_results',
                 'data' => [
                    'labResults' => $patient->labResults()->with('exam')->get(), // Charger la relation et sous-relation
                ],
                 'order' => 40,
            ],
             [
                'id' => 'patient_billing',
                'title' => __('hopital::lang.billing'),
                'view' => 'hopital::patients.tabs.billing',
                 'data' => [
                    'bills' => $patient->hospitalBills, // Supposons une relation `hospitalBills`
                ],
                 'order' => 50,
            ],
            // Ajoutez d'autres onglets pertinents ici (ex: Plans de traitement, Notes cliniques, etc.)
        ];
    }

    /**
     * Ajoute les taxonomies essentielles spécifiques au module Hôpital.
     *
     * Inspiré de addTaxonomies du module CRM.
     * Cette méthode retourne la configuration des taxonomies à créer ou gérer par le système principal.
     *
     * @return array Un tableau de configurations de taxonomies.
     */
    public function addTaxonomies()
    {
        $module_util = new ModuleUtil();
        $business_id = request()->session()->get('user.business_id');

        $output = [];

        // Vérifier si le module est activé et si l'utilisateur a la permission de gérer les paramètres du module
        if (! (auth()->user()->can('superadmin') || $module_util->hasThePermissionInSubscription($business_id, 'hopital_module')) ) {
            return $output;
        }

        // Définir les taxonomies pour le module Hôpital
        // Le format doit correspondre à ce que le système principal attend (basé sur le CRM)
        $output['patient_status'] = [
            'taxonomy_label' => __('hopital::lang.patient_status'),
            'heading' => __('hopital::lang.patient_statuses'),
            'sub_heading' => __('hopital::lang.manage_patient_statuses'),
            'enable_taxonomy_code' => false, // Adapter si besoin
            'enable_sub_taxonomy' => false, // Adapter si besoin
            'heading_tooltip' => __('hopital::lang.patient_status_tooltip'), // Tooltip localisé
            'navbar' => 'hopital::layouts.nav', // Navbar à afficher sur la page de gestion de cette taxonomie
             'priority' => 10, // Ordre d'affichage dans la liste des taxonomies
        ];

         $output['urgency_level'] = [
            'taxonomy_label' => __('hopital::lang.urgency_level'),
            'heading' => __('hopital::lang.urgency_levels'),
            'sub_heading' => __('hopital::lang.manage_urgency_levels'),
            'enable_taxonomy_code' => false,
            'enable_sub_taxonomy' => false,
            'heading_tooltip' => __('hopital::lang.urgency_level_tooltip'),
            'navbar' => 'hopital::layouts.nav',
             'priority' => 20,
        ];

         $output['medical_specialty'] = [
            'taxonomy_label' => __('hopital::lang.medical_specialty'),
            'heading' => __('hopital::lang.medical_specialties'),
            'sub_heading' => __('hopital::lang.manage_medical_specialties'),
            'enable_taxonomy_code' => false,
            'enable_sub_taxonomy' => false,
            'heading_tooltip' => __('hopital::lang.medical_specialty_tooltip'),
            'navbar' => 'hopital::layouts.nav',
             'priority' => 30,
        ];

        $output['service_type'] = [
            'taxonomy_label' => __('hopital::lang.service_type'),
            'heading' => __('hopital::lang.service_types'),
            'sub_heading' => __('hopital::lang.manage_service_types'),
            'enable_taxonomy_code' => false,
            'enable_sub_taxonomy' => false,
            'heading_tooltip' => __('hopital::lang.service_type_tooltip'),
            'navbar' => 'hopital::layouts.nav',
             'priority' => 40,
        ];

        // Ajoutez d'autres taxonomies si nécessaire (ex: Types de Chambre, Raisons d'admission, Types d'examen)

        return $output;
    }

    /**
     * Définit les permissions utilisateur spécifiques au module Hôpital.
     *
     * Inspiré de user_permissions du module CRM.
     * Retourne la liste des permissions dans un format structuré pour le système de gestion des rôles.
     *
     * @return array Un tableau de configurations de permissions.
     */
    public function user_permissions()
    {
        // S'inspirer de la structure du CRM DataController
        $permissions = [
            // Permissions pour la gestion des patients
            [ 'value' => 'hopital.patient.view', 'label' => __('hopital::lang.can_view_patients'), 'default' => false ],
            [ 'value' => 'hopital.patient.create', 'label' => __('hopital::lang.can_add_patients'), 'default' => false ],
            [ 'value' => 'hopital.patient.edit', 'label' => __('hopital::lang.can_edit_patients'), 'default' => false ],
            [ 'value' => 'hopital.patient.delete', 'label' => __('hopital::lang.can_delete_patients'), 'default' => false ], // Ou can_archive_patients
            [ 'value' => 'hopital.patient.view_medical_history', 'label' => __('hopital::lang.can_view_medical_history'), 'default' => false ],
            // ... autres permissions patient

            // Permissions pour la gestion des rendez-vous
            [ 'value' => 'hopital.appointment.view', 'label' => __('hopital::lang.can_view_appointments'), 'default' => false, 'is_radio' => true, 'radio_input_name' => 'appointment_view' ],
            [ 'value' => 'hopital.appointment.view_all', 'label' => __('hopital::lang.can_view_all_appointments'), 'default' => false, 'is_radio' => true, 'radio_input_name' => 'appointment_view', 'end_group' => true ],
            [ 'value' => 'hopital.appointment.create', 'label' => __('hopital::lang.can_add_appointments'), 'default' => false ],
            [ 'value' => 'hopital.appointment.edit', 'label' => __('hopital::lang.can_edit_appointments'), 'default' => false ],
            [ 'value' => 'hopital.appointment.delete', 'label' => __('hopital::lang.can_delete_appointments'), 'default' => false ],

            // Permissions pour la gestion du personnel (vue planning principalement)
            [ 'value' => 'hopital.staff.view_schedule', 'label' => __('hopital::lang.can_view_staff_schedule'), 'default' => false ],
            [ 'value' => 'hopital.staff.manage_schedule', 'label' => __('hopital::lang.can_manage_staff_schedule'), 'default' => false ],
             // Les permissions CRUD sur les utilisateurs sont généralement gérées par le module User principal

            // Permissions pour les hospitalisations et lits
            [ 'value' => 'hopital.inpatient.view', 'label' => __('hopital::lang.can_view_inpatients'), 'default' => false ],
            [ 'value' => 'hopital.inpatient.admit', 'label' => __('hopital::lang.can_admit_patient'), 'default' => false ],
            [ 'value' => 'hopital.inpatient.discharge', 'label' => __('hopital::lang.can_discharge_patient'), 'default' => false ],
            [ 'value' => 'hopital.inpatient.edit', 'label' => __('hopital::lang.can_edit_hospitalizations'), 'default' => false ],
            [ 'value' => 'hopital.bed.view', 'label' => __('hopital::lang.can_view_beds'), 'default' => false ],
            [ 'value' => 'hopital.bed.manage', 'label' => __('hopital::lang.can_manage_beds'), 'default' => false ], // Gérer lits/chambres

            // Permissions pour le laboratoire
            [ 'value' => 'hopital.lab.view_orders', 'label' => __('hopital::lang.can_view_lab_orders'), 'default' => false ],
            [ 'value' => 'hopital.lab.create_order', 'label' => __('hopital::lang.can_create_lab_orders'), 'default' => false ],
            [ 'value' => 'hopital.lab.view_results', 'label' => __('hopital::lang.can_view_lab_results'), 'default' => false ],
            [ 'value' => 'hopital.lab.upload_results', 'label' => __('hopital::lang.can_upload_lab_results'), 'default' => false ],

            // Permissions pour la facturation et les assurances
            [ 'value' => 'hopital.billing.view', 'label' => __('hopital::lang.can_view_hospital_billing'), 'default' => false ],
            [ 'value' => 'hopital.billing.create', 'label' => __('hopital::lang.can_create_hospital_bills'), 'default' => false ],
            [ 'value' => 'hopital.billing.edit', 'label' => __('hopital::lang.can_edit_hospital_bills'), 'default' => false ],
            [ 'value' => 'hopital.billing.process_payment', 'label' => __('hopital::lang.can_process_hospital_payments'), 'default' => false ],
            [ 'value' => 'hopital.insurance.view_claims', 'label' => __('hopital::lang.can_view_insurance_claims'), 'default' => false ],
            [ 'value' => 'hopital.insurance.manage_claims', 'label' => __('hopital::lang.can_manage_insurance_claims'), 'default' => false ],

            // Permissions pour les urgences
            [ 'value' => 'hopital.emergency.view', 'label' => __('hopital::lang.can_view_emergencies'), 'default' => false ],
            [ 'value' => 'hopital.emergency.trigger_alert', 'label' => __('hopital::lang.can_trigger_emergency_alert'), 'default' => false ],
            [ 'value' => 'hopital.emergency.manage_response', 'label' => __('hopital::lang.can_manage_emergency_response'), 'default' => false ],

            // Permission générale pour accéder au module
            [ 'value' => 'hopital.access_module', 'label' => __('hopital::lang.can_access_hopital_module'), 'default' => false ],
        ];

        // Vous pourriez ajouter d'autres permissions basées sur des constantes ou des configurations spécifiques
        /*
        if (config('constants.enable_specific_feature')) {
             $permissions[] = [ ... ];
        }
        */

        return $permissions;
    }

    /**
     * Retourne des éléments supplémentaires (JS, CSS, HTML) à inclure
     * dans le layout principal de l'application.
     *
     * Inspiré de get_additional_script du module CRM.
     *
     * @return array Un tableau d'éléments à inclure, avec un type ('js', 'css', 'html')
     */
    public function get_additional_script()
    {
        // S'inspirer de la structure de retour du CRM DataController
        $additional_js = ''; // Code JS inline si nécessaire
        $additional_css = ''; // Code CSS inline si nécessaire
        $additional_html = ''; // Code HTML inline si nécessaire

        // Liste des fichiers JS/CSS à inclure (à adapter selon vos besoins)
        $additional_files = [
            // Exemple d'inclusion d'un fichier CSS spécifique au module
            [
                'type' => 'css',
                'src' => asset('modules/hopital/css/hopital_global.css'), // Assurez-vous que l'asset est publié
                 'order' => 10, // Optionnel: ordre d'inclusion
            ],
            // Exemple d'inclusion d'un fichier JS spécifique au module
            [
                'type' => 'js',
                'src' => asset('modules/hopital/js/hopital_global.js'), // Assurez-vous que l'asset est publié
                 'order' => 10,
            ],
        ];

        return [
            'additional_js' => $additional_js,
            'additional_css' => $additional_css,
            'additional_html' => $additional_html,
            'additional_files' => $additional_files, // Utilisation de 'additional_files' pour la liste
             // 'additional_views' => [], // Le CRM avait 'additional_views', à inclure si pertinent
        ];
    }

    // --- Autres méthodes utiles inspirées du scénario et du CRM DataController ---

    /**
     * Hook déclenché après l'enregistrement d'un nouveau patient.
     * Permet d'initialiser des données spécifiques au module Hôpital pour ce patient.
     * Inspiré de after_contact_saved du module CRM.
     *
     * @param array $data Contient l'objet patient et les données d'entrée.
     * @return void
     */
    public function after_patient_saved($data)
    {
        $patient = $data['patient']; // Supposons que le patient enregistré soit passé ici
        $input = $data['input'];   // Les données soumises lors de l'enregistrement

        // Logique pour initialiser les données hôpital pour le nouveau patient
        // Par exemple, créer un enregistrement de dossier médical vide ou définir un statut par défaut.

        // Exemple conceptuel: Créer un enregistrement initial dans l'historique médical
        /*
        if (! $patient->medicalHistory()->exists()) {
             $patient->medicalHistory()->create([
                'patient_id' => $patient->id,
                // Autres champs d'initialisation...
             ]);
        }
        */

        // Logique pour attacher le patient à un utilisateur contact CRM si nécessaire
        // (si le système H360 lie patients et contacts CRM)
        /*
        if (isset($input['create_contact_person']) && $input['create_contact_person']) {
             // Créer un utilisateur dans le système principal lié à ce patient
             // Similaire à la logique de création de contact person dans le CRM
        }
        */

         // \Log::info("Hook after_patient_saved déclenché pour le patient ID: " . $patient->id);
    }

    /**
     * Hook déclenché après la décharge (sortie) d'un patient hospitalisé.
     * **Très Important:** C'est ici que l'on déclenche le processus de facturation finale.
     * Inspiré de after_payment_status_updated (déclenchement facture/commission) du CRM, mais adapté au contexte hôpital.
     *
     * @param array $data Contient l'objet Hospitalization.
     * @return void
     */
    public function after_hospitalization_discharged($data)
    {
        $hospitalization = $data['hospitalization']; // L'objet Hospitalization déchargé

        // --- Déclencher le processus de facturation finale pour cette hospitalisation ---
        // Au lieu de faire toute la logique de facturation ici, on déclenche un événement
        // ou on appelle un service dédié.
        // C'est une bonne pratique pour garder les hooks légers.

        // Exemple conceptuel :
        try {
            // Appeler un service de facturation du module Hôpital
            // $billingService = app(\Modules\Hopital\Services\BillingService::class);
            // $billingService->generateFinalHospitalizationBill($hospitalization);

            // Ou déclencher un événement que d'autres listeners peuvent écouter (ex: service de facturation, notifications)
            // event(new \Modules\Hopital\Events\HospitalizationDischarged($hospitalization));

            \Log::info("Hook after_hospitalization_discharged déclenché. Tentative de déclenchement de la facturation finale pour l'hospitalisation ID: " . $hospitalization->id);

        } catch (\Exception $e) {
            \Log::error("Erreur lors du déclenchement de la facturation post-décharge pour l'hospitalisation ID: " . $hospitalization->id . " - " . $e->getMessage());
             // Gérer l'erreur, potentiellement notifier un administrateur
        }

        // Vous pourriez aussi ajouter d'autres logiques post-décharge ici :
        // - Notifier le service de nettoyage pour le lit
        // - Archiver l'enregistrement (si suppression logique)
        // - Envoyer un email de suivi au patient (si pertinent)
    }

     /**
     * Fetches all calendar events specific to the module (e.g., Appointments, Procedures).
     *
     * Inspiré de calendarEvents du module CRM.
     *
     * @param  array  $data Contient 'business_id', 'start_date', 'end_date', 'user_id' (optionnel).
     * @return array Un tableau d'événements formatés pour un calendrier (ex: FullCalendar).
     */
    public function calendarEvents($data)
    {
        $events = [];

        // Vérifier si le module est activé et si l'utilisateur a la permission de voir les calendriers
        $module_util = new ModuleUtil();
        $is_hopital_enabled = (bool) $module_util->hasThePermissionInSubscription($data['business_id'], 'hopital_module');
        $can_view_appointments = auth()->user()->can('hopital.appointment.view'); // Ou une permission plus générale

        if (!$is_hopital_enabled || !$can_view_appointments) {
            return [];
        }

        // Exemple: Récupérer les rendez-vous dans la plage de dates demandée
        $appointments = Appointment::where('business_id', $data['business_id'])
                                 ->whereBetween('start_datetime', [$data['start_date'], $data['end_date']])
                                 ->get();

        foreach ($appointments as $appointment) {
            $events[] = [
                'title' => $appointment->title ?? 'Rendez-vous', // Ou un format plus descriptif
                'start' => $appointment->start_datetime,
                'end' => $appointment->end_datetime,
                'url' => route('hopital.appointments.show', $appointment->id), // Lien vers la vue du rendez-vous
                'backgroundColor' => '#0073b7', // Exemple de couleur (info)
                'borderColor' => '#0073b7',
                'event_type' => 'hopital_appointment', // Type unique pour différencier
                'allDay' => false, // Adapter si les rendez-vous peuvent être sur toute la journée
            ];
        }

        // Vous pourriez ajouter d'autres types d'événements ici (ex: procédures planifiées, réunions de personnel)
        // $procedures = Procedure::where(...)->get(); // Supposons un modèle Procedure
        // foreach($procedures as $proc) { ... $events[] = [...] ... }

        return $events;
    }

     /**
     * List of calendar event types provided by the module.
     *
     * Inspiré de eventTypes du module CRM.
     * Utilisé par le calendrier principal pour afficher une légende.
     *
     * @return array Un tableau d'éléments de type d'événement.
     */
    public function eventTypes()
    {
         $module_util = new ModuleUtil();
         $business_id = request()->session()->get('user.business_id');
         $is_hopital_enabled = (bool) $module_util->hasThePermissionInSubscription($business_id, 'hopital_module');

         if (!$is_hopital_enabled) {
             return [];
         }

        return [
            'hopital_appointment' => [
                'label' => __('hopital::lang.appointment'), // Libellé localisé
                'color' => '#0073b7', // Couleur correspondante
            ],
             // Ajoutez d'autres types si vous en avez dans calendarEvents()
            /*
             'hopital_procedure' => [
                'label' => __('hopital::lang.procedure'),
                'color' => '#f39c12', // Exemple couleur (warning)
            ],
            */
        ];
    }

    /**
     * Hook pour ajouter des champs au formulaire de création/édition de patient/contact principal.
     *
     * Inspiré de contact_form_part du module CRM.
     * Permet d'injecter une partie de vue Blade spécifique au module Hôpital.
     *
     * @return array Contient le chemin de la vue partielle et les données à lui passer.
     */
    public function patient_form_part()
    {
         $module_util = new ModuleUtil();
         $business_id = request()->session()->get('user.business_id');
         $is_hopital_enabled = (bool) $module_util->hasThePermissionInSubscription($business_id, 'hopital_module');

         if (!$is_hopital_enabled) {
             return [];
         }

        // Retourne le chemin de la vue partielle à inclure dans le formulaire principal
        return  [
            'template_path' => 'hopital::patients.partials.patient_form_fields', // Chemin de la vue partielle Blade
            'template_data' => [], // Données optionnelles à passer à la vue partielle
        ];
    }

     /**
     * Fournit des configurations pour les widgets de tableau de bord.
     *
     * Cette méthode est appelée par le système de tableau de bord principal
     * pour collecter les widgets des différents modules.
     *
     * @return array Un tableau de configurations de widgets.
     */
    public function dashboard_widgets()
    {
         $module_util = new ModuleUtil();
         $business_id = request()->session()->get('user.business_id');
         $is_hopital_enabled = (bool) $module_util->hasThePermissionInSubscription($business_id, 'hopital_module');

         if (!$is_hopital_enabled) {
             return [];
         }

         $widgets = [];

         // Widget: Patients actuellement hospitalisés
         if (auth()->user()->can('hopital.inpatient.view')) { // Vérifier la permission
             $widgets[] = [
                 'id' => 'hopital_active_inpatients',
                 'title' => __('hopital::lang.active_hospitalizations'),
                 'view' => 'hopital::dashboard.widgets.active_inpatients', // Vue pour le contenu du widget
                 'data' => [
                     'activeInpatientsCount' => Hospitalization::where('business_id', $business_id)->whereNull('discharge_date')->count(),
                     // Vous pourriez passer ici une liste limitée de patients ou d'autres stats
                 ],
                 'priority' => 10, // Ordre d'affichage du widget
                 'size' => 'col-md-6 col-lg-4', // Classes CSS pour la taille (ex: Bootstrap grid)
             ];
         }

         // Widget: Rendez-vous du jour
         if (auth()->user()->can('hopital.appointment.view')) {
              $widgets[] = [
                 'id' => 'hopital_today_appointments',
                 'title' => __('hopital::lang.todays_appointments'),
                 'view' => 'hopital::dashboard.widgets.today_appointments',
                 'data' => [
                     'todayAppointmentsCount' => Appointment::where('business_id', $business_id)
                                                            ->whereDate('start_datetime', today())
                                                            ->count(),
                     // Liste des prochains rendez-vous...
                 ],
                 'priority' => 20,
                 'size' => 'col-md-6 col-lg-4',
             ];
         }

         // Widget: Lits disponibles
          if (auth()->user()->can('hopital.bed.view')) {
               $widgets[] = [
                 'id' => 'hopital_available_beds',
                 'title' => __('hopital::lang.available_beds'),
                 'view' => 'hopital::dashboard.widgets.available_beds',
                 'data' => [
                     'availableBedsCount' => \Modules\Hopital\Entities\Bed::where('business_id', $business_id)->where('is_available', true)->count(),
                 ],
                 'priority' => 30,
                 'size' => 'col-md-6 col-lg-4',
             ];
         }

         // Ajoutez d'autres widgets (Urgences en cours, Résultats Labo en attente, etc.)

         return $widgets;
    }


    // Vous pourriez ajouter d'autres hooks si le système principal en propose :
    // - after_user_deleted
    // - after_business_created/updated
    // - register_settings (pour ajouter des paramètres dans l'interface de configuration de l'app principale)
    // - ...

}