<?php

namespace Modules\Hopital\Http\Controllers\Api;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\Hospitalization; // Modèle pour les hospitalisations
use Modules\Hopital\Entities\Patient;       // Modèle pour les patients
use Modules\Hopital\Entities\Bed;           // Modèle pour les lits
use Modules\Hopital\Http\Requests\Api\StoreHospitalizationRequest; // Pour validation de l'admission
use Modules\Hopital\Http\Requests\Api\UpdateHospitalizationRequest; // Pour validation des mises à jour
use Modules\Hopital\Http\Requests\Api\DischargeHospitalizationRequest; // Pour validation de la sortie

// N'oubliez pas de créer ces classes Request dans Modules/Hopital/Http/Requests/Api/

class InpatientApiController extends Controller
{
    /**
     * Affiche la liste des hospitalisations (patients actuellement hospitalisés ou historique).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        // On peut filtrer ici, par exemple, pour ne montrer que les hospitalisations actives
        $hospitalizations = Hospitalization::with(['patient', 'bed.room', 'admittingStaff', 'dischargingStaff'])
                                          ->whereNull('discharge_date') // Filtrer les patients actuellement hospitalisés
                                          ->latest()
                                          ->paginate(10); // Pagination pour de meilleures performances

        // Idéalement, utiliser une ressource API pour formater la sortie
        // return HospitalizationResource::collection($hospitalizations);

        return response()->json([
            'success' => true,
            'data' => $hospitalizations,
            'message' => 'Liste des hospitalisations récupérée avec succès.'
        ]);
    }

    /**
     * Enregistre une nouvelle hospitalisation (admission d'un patient).
     *
     * @param  StoreHospitalizationRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(StoreHospitalizationRequest $request)
    {
        // La validation est gérée par StoreHospitalizationRequest

        // Vérifier si le patient existe
        $patient = Patient::find($request->patient_id);
        if (!$patient) {
            return response()->json(['success' => false, 'message' => 'Patient non trouvé.'], 404);
        }

        // Vérifier si le lit existe et est disponible
        $bed = Bed::find($request->bed_id);
        if (!$bed) {
            return response()->json(['success' => false, 'message' => 'Lit non trouvé.'], 404);
        }
        if (!$bed->is_available) {
             // On pourrait aussi vérifier qu'aucun autre patient n'est assigné à ce lit pour une période donnée
             // $isOccupied = Hospitalization::where('bed_id', $bed->id)->whereNull('discharge_date')->exists();
            return response()->json(['success' => false, 'message' => 'Le lit sélectionné n\'est pas disponible.'], 400);
        }

        // Créer l'enregistrement d'hospitalisation
        $hospitalization = Hospitalization::create($request->validated());

        // Marquer le lit comme occupé
        $bed->is_available = false;
        $bed->save();

        // Charger les relations pour la réponse
        $hospitalization->load(['patient', 'bed.room', 'admittingStaff']);

        // Idéalement, utiliser une ressource API pour formater la sortie
        // return new HospitalizationResource($hospitalization);

        return response()->json([
            'success' => true,
            'data' => $hospitalization,
            'message' => 'Hospitalisation enregistrée avec succès.',
            'bed_status_updated' => true // Indiquer que le statut du lit a été mis à jour
        ], 201);
    }

    /**
     * Affiche les détails d'une hospitalisation spécifique.
     *
     * @param  int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $hospitalization = Hospitalization::with(['patient', 'bed.room', 'admittingStaff', 'dischargingStaff'])
                                          ->find($id);

        if (!$hospitalization) {
            return response()->json(['success' => false, 'message' => 'Hospitalisation non trouvée.'], 404);
        }

        // Idéalement, utiliser une ressource API
        // return new HospitalizationResource($hospitalization);

        return response()->json([
            'success' => true,
            'data' => $hospitalization,
            'message' => 'Détails de l\'hospitalisation récupérés avec succès.'
        ]);
    }

    /**
     * Met à jour les informations d'une hospitalisation existante.
     * Peut inclure le changement de lit.
     *
     * @param  UpdateHospitalizationRequest $request
     * @param  int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(UpdateHospitalizationRequest $request, $id)
    {
        $hospitalization = Hospitalization::find($id);

        if (!$hospitalization) {
            return response()->json(['success' => false, 'message' => 'Hospitalisation non trouvée.'], 404);
        }

        $originalBedId = $hospitalization->bed_id;

        $hospitalization->update($request->validated());

        // Gérer le changement de lit si bed_id a été modifié dans la requête validée
        if ($request->has('bed_id') && $request->bed_id != $originalBedId) {
            $newBed = Bed::find($request->bed_id);

            if (!$newBed) {
                 // Rollback ou gérer l'erreur - ici, on renvoie juste une erreur
                 return response()->json(['success' => false, 'message' => 'Nouveau lit non trouvé.'], 404);
            }

            if (!$newBed->is_available) {
                 // Gérer l'erreur - le nouveau lit n'est pas disponible
                 // On pourrait annuler la mise à jour de l'hospitalisation ou demander confirmation
                 return response()->json(['success' => false, 'message' => 'Le nouveau lit sélectionné n\'est pas disponible.'], 400);
            }

            // Marquer l'ancien lit comme disponible
            $oldBed = Bed::find($originalBedId);
            if ($oldBed) {
                 $oldBed->is_available = true;
                 $oldBed->save();
            }

            // Marquer le nouveau lit comme occupé
            $newBed->is_available = false;
            $newBed->save();
        }


        $hospitalization->load(['patient', 'bed.room', 'admittingStaff', 'dischargingStaff']);

        // Idéalement, utiliser une ressource API
        // return new HospitalizationResource($hospitalization);

        return response()->json([
            'success' => true,
            'data' => $hospitalization,
            'message' => 'Hospitalisation mise à jour avec succès.'
        ]);
    }

    /**
     * Marque une hospitalisation comme terminée (sortie du patient).
     *
     * @param  DischargeHospitalizationRequest $request
     * @param  int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function discharge(DischargeHospitalizationRequest $request, $id)
    {
        $hospitalization = Hospitalization::with('bed')->find($id);

        if (!$hospitalization || $hospitalization->discharge_date !== null) {
            // Ne peut pas décharger une hospitalisation non trouvée ou déjà déchargée
            return response()->json(['success' => false, 'message' => 'Hospitalisation non trouvée ou déjà terminée.'], 404);
        }

        // La validation est gérée par DischargeHospitalizationRequest
        $validatedData = $request->validated();

        // Mettre à jour les informations de sortie
        $hospitalization->discharge_date = $validatedData['discharge_date'] ?? now(); // Utilisez la date de la requête ou la date actuelle
        $hospitalization->discharge_summary = $validatedData['discharge_summary'] ?? null;
        $hospitalization->discharging_staff_id = $validatedData['discharging_staff_id'] ?? auth()->id(); // Staff qui effectue la sortie
        // Autres champs de sortie si nécessaire
        $hospitalization->save();

        // Marquer le lit comme disponible
        if ($hospitalization->bed) {
            $hospitalization->bed->is_available = true;
            $hospitalization->bed->save();
        }

        // --- Déclencher le processus de facturation finale ---
        // C'est ici que vous devriez déclencher la génération de la facture finale
        // en fonction de la durée de l'hospitalisation, des services reçus, etc.
        // Cela pourrait impliquer un appel à un service ou le déclenchement d'un événement.
        // Exemple conceptuel :
        // BillingService::generateFinalHospitalizationBill($hospitalization);
        // event(new HospitalizationDischarged($hospitalization));
        // ---------------------------------------------------


        $hospitalization->load(['patient', 'bed.room', 'admittingStaff', 'dischargingStaff']);


        // Idéalement, utiliser une ressource API
        // return new HospitalizationResource($hospitalization);

        return response()->json([
            'success' => true,
            'data' => $hospitalization,
            'message' => 'Patient déchargé avec succès.',
            'bed_status_updated' => true, // Indiquer que le statut du lit a été mis à jour
            'billing_process_triggered' => true // Indiquer que la facturation est en cours
        ]);
    }

    // NOTE: Une méthode `destroy` pour supprimer une hospitalisation est rare et déconseillée
    // dans un système médical pour des raisons d'auditabilité. Préférer l'état `déchargé`.
}