<?php

namespace Modules\Hopital\Http\Controllers\Api;

use App\Http\Controllers\Controller; // Utilisez le contrôleur de base de votre application principale ou de Laravel
use Illuminate\Http\Request;
use Modules\Hopital\Entities\Patient; // Assurez-vous que ce chemin est correct vers votre modèle Patient
use Modules\Hopital\Http\Requests\Api\StorePatientRequest; // Nous allons créer cette FormRequest plus tard pour la validation
use Modules\Hopital\Http\Requests\Api\UpdatePatientRequest; // Nous allons créer cette FormRequest plus tard pour la validation
use Modules\Hopital\Transformers\PatientResource; // Nous allons créer cette Resource plus tard pour formater la réponse API
use Illuminate\Http\JsonResponse;

class PatientApiController extends Controller
{
    /**
     * Affiche une liste de tous les patients.
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function index(Request $request): JsonResponse
    {
        // Exemple basique : récupération de tous les patients.
        // Pour une application réelle, ajoutez pagination, filtres, recherche, etc.
        $patients = Patient::paginate($request->get('per_page', 15)); // Exemple avec pagination

        // Utilisation d'une Resource Collection pour formater la liste
        return PatientResource::collection($patients)->response();
    }

    /**
     * Enregistre un nouveau patient.
     * Correspond au point 1.1 du scénario (Enregistrement du Patient).
     *
     * @param StorePatientRequest $request // Utilisation d'une FormRequest pour la validation
     * @return JsonResponse
     */
    public function store(StorePatientRequest $request): JsonResponse
    {
        // Les données validées sont disponibles via $request->validated()
        $data = $request->validated();

        // Création du patient
        $patient = Patient::create($data);

        // Vous pourriez ajouter ici la logique pour créer la "Fiche de Traitement" initiale
        // par exemple, une entrée vide dans l'historique médical si applicable.

        // Retourne la réponse avec le patient créé (status 201 Created)
        return (new PatientResource($patient))
               ->response()
               ->setStatusCode(JsonResponse::HTTP_CREATED); // 201 Created
    }

    /**
     * Affiche les détails d'un patient spécifique.
     * Correspond au point 1.2 (Fiche de Traitement) et 4.1/4.2 (Dossiers Médicaux).
     *
     * @param int $id
     * @return JsonResponse
     */
    public function show(int $id): JsonResponse
    {
        // Trouve le patient par ID ou lance une exception 404
        $patient = Patient::findOrFail($id);

        // Charge les relations nécessaires pour la "Fiche de Traitement"
        // Assurez-vous que ces relations sont définies dans le modèle Patient
        $patient->load([
            'medicalHistory', // Point 1.2
            'allergies',      // Point 1.2
            'medications',    // Point 1.2
            'examResults'     // Point 1.2 / 6.2
            // Ajoutez d'autres relations si nécessaire (hospitalisations actuelles, etc.)
        ]);

        // Retourne le patient avec ses relations chargées
        return (new PatientResource($patient))->response(); // 200 OK par défaut
    }

    /**
     * Met à jour les informations d'un patient existant.
     *
     * @param UpdatePatientRequest $request // Utilisation d'une FormRequest pour la validation
     * @param int $id
     * @return JsonResponse
     */
    public function update(UpdatePatientRequest $request, int $id): JsonResponse
    {
        // Trouve le patient
        $patient = Patient::findOrFail($id);

        // Les données validées
        $data = $request->validated();

        // Mise à jour du patient
        $patient->update($data);

        // Retourne le patient mis à jour
        return (new PatientResource($patient))->response(); // 200 OK par défaut
    }

    /**
     * Supprime un patient.
     * Note : Pour des raisons de conformité médicale et de traçabilité,
     * une suppression "soft delete" est fortement recommandée ici.
     *
     * @param int $id
     * @return JsonResponse
     */
    public function destroy(int $id): JsonResponse
    {
        // Trouve le patient
        $patient = Patient::findOrFail($id);

        // Effectue une suppression (idéalement soft delete si configuré sur le modèle)
        $patient->delete();

        // Retourne une réponse vide ou un message de succès (status 204 No Content)
        return response()->json(null, JsonResponse::HTTP_NO_CONTENT); // 204 No Content
    }

    // Vous pourriez ajouter ici d'autres méthodes API spécifiques, par exemple :
    // public function addMedicalHistory(Request $request, int $patientId) { ... }
    // public function addAllergy(Request $request, int $patientId) { ... }
    // etc., si vous préférez des points de terminaison plus granulaires.
}