<?php

namespace Modules\Hopital\Http\Controllers;

use Illuminate\Routing\Controller;
use Modules\Hopital\Entities\Appointment;
use Modules\Hopital\Entities\Bed;
use Modules\Hopital\Entities\Bill;
use Modules\Hopital\Entities\Emergency;
use Modules\Hopital\Entities\Hospitalization;
use Modules\Hopital\Entities\InsuranceClaim;
use Modules\Hopital\Entities\LabResult;
use Modules\Hopital\Entities\Patient;
use Modules\Hopital\Entities\Staff;
use Carbon\Carbon; // Assurez-vous que Carbon est installé ou disponible

class HopitalController extends Controller
{
    /**
     * Affiche le tableau de bord du module Hôpital.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // Récupération des statistiques pour le tableau de bord
        $totalPatients = Patient::count();
        $appointmentsToday = Appointment::whereDate('appointment_at', Carbon::today())->count();
        $availableBeds = Bed::where('status', 'available')->count(); // Supposons un champ 'status' sur le modèle Bed
        $hospitalizedPatients = Hospitalization::whereNull('discharge_date')->count(); // Supposons 'discharge_date' pour les sorties
        $totalStaff = Staff::count();
        $pendingLabResults = LabResult::where('status', 'pending')->count(); // Supposons un champ 'status' sur le modèle LabResult
        $recentEmergenciesLast24h = Emergency::where('created_at', '>=', Carbon::now()->subDay())->count();
        // Note : Pour les statistiques financières, il faudrait peut-être spécifier une période (aujourd'hui, ce mois, etc.)
        // Exemple simple: total des factures impayées
        $unpaidBills = Bill::where('status', 'unpaid')->count(); // Supposons un champ 'status' sur le modèle Bill


        return view('hopital::dashboard', compact(
            'totalPatients',
            'appointmentsToday',
            'availableBeds',
            'hospitalizedPatients',
            'totalStaff',
            'pendingLabResults',
            'recentEmergenciesLast24h',
            'unpaidBills'
        ));
    }
}