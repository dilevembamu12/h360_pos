<?php

namespace Modules\Hopital\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StorePatientRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // Ici, vous pouvez ajouter la logique d'autorisation.
        // Par exemple, vérifier si l'utilisateur a la permission 'create patient'.
        // Pour l'instant, nous autorisons toutes les requêtes si l'utilisateur est authentifié.
        return auth()->check();

        // Si vous avez un système de permission spécifique, vous pourriez avoir quelque chose comme :
        // return auth()->user()->can('create patient');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'date_of_birth' => 'required|date',
            'gender' => 'required|in:Male,Female,Other', // ou 'required|in:homme,femme,autre' selon votre nomenclature
            'phone_number' => 'nullable|string|max:20', // Utiliser nullable si le champ n'est pas obligatoire
            'address' => 'nullable|string|max:500',
            'email' => 'nullable|email|unique:hopital_patients,email', // Assurez-vous que la table est correcte
            'blood_type' => 'nullable|string|max:5',
            'is_inpatient' => 'required|boolean', // Pour distinguer ambulatoire/hospitalisé dès l'enregistrement
            // Ajoutez d'autres champs pertinents ici (assurance, contact d'urgence, etc.)
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'first_name.required' => 'Le prénom du patient est obligatoire.',
            'last_name.required' => 'Le nom du patient est obligatoire.',
            'date_of_birth.required' => 'La date de naissance est obligatoire.',
            'date_of_birth.date' => 'La date de naissance doit être une date valide.',
            'gender.required' => 'Le genre est obligatoire.',
            'gender.in' => 'Le genre doit être Homme, Femme ou Autre.',
            'email.unique' => 'Cet email est déjà utilisé par un autre patient.',
            'is_inpatient.required' => 'Le statut d\'hospitalisation (ambulatoire/hospitalisé) est obligatoire.',
            'is_inpatient.boolean' => 'Le statut d\'hospitalisation doit être un booléen.',
        ];
    }
}