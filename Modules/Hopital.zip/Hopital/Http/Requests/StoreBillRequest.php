<?php

namespace Modules\Hopital\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreBillRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // Autoriser si l'utilisateur est authentifié et potentiellement a la permission 'create bill'.
        return auth()->check();
        // return auth()->user()->can('create bill');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'patient_id' => 'required|exists:hopital_patients,id', // Le patient concerné par la facture
            'bill_date' => 'required|date', // Date de la facture
            'due_date' => 'required|date|after_or_equal:bill_date', // Date d'échéance
            'status' => 'required|in:Pending,Paid,Partially Paid,Cancelled,Bad Debt', // Statut de la facture
            'total_amount' => 'required|numeric|min:0', // Montant total (peut être calculé côté serveur aussi)
            'discount_amount' => 'nullable|numeric|min:0', // Montant de la réduction
            'tax_amount' => 'nullable|numeric|min:0', // Montant des taxes
            'paid_amount' => 'nullable|numeric|min:0|lte:total_amount', // Montant déjà payé
            'notes' => 'nullable|string', // Notes sur la facture
            // Validation des lignes de facture (suppose un tableau 'items')
            'items' => 'required|array|min:1', // La facture doit avoir au moins un élément
            'items.*.description' => 'required|string|max:255', // Description de l'élément
            'items.*.quantity' => 'required|integer|min:1', // Quantité
            'items.*.unit_price' => 'required|numeric|min:0', // Prix unitaire
            // Optionnel: pourrait inclure 'items.*.service_id' ou 'items.*.medication_id' pour lier aux éléments du catalogue
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'patient_id.required' => 'Le patient est obligatoire pour la facture.',
            'patient_id.exists' => 'Le patient sélectionné n\'existe pas.',
            'bill_date.required' => 'La date de la facture est obligatoire.',
            'bill_date.date' => 'La date de la facture doit être une date valide.',
            'due_date.required' => 'La date d\'échéance est obligatoire.',
            'due_date.date' => 'La date d\'échéance doit être une date valide.',
            'due_date.after_or_equal' => 'La date d\'échéance doit être égale ou postérieure à la date de la facture.',
            'status.required' => 'Le statut de la facture est obligatoire.',
            'status.in' => 'Le statut de la facture n\'est pas valide.',
            'total_amount.required' => 'Le montant total est obligatoire.',
            'total_amount.numeric' => 'Le montant total doit être un nombre.',
            'total_amount.min' => 'Le montant total doit être positif.',
            'paid_amount.lte' => 'Le montant payé ne peut pas être supérieur au montant total.',
            'items.required' => 'La facture doit contenir des éléments.',
            'items.array' => 'Les éléments de la facture doivent être dans un format de liste.',
            'items.min' => 'La facture doit contenir au moins un élément.',
            'items.*.description.required' => 'La description de l\'élément est obligatoire.',
            'items.*.quantity.required' => 'La quantité de l\'élément est obligatoire.',
            'items.*.quantity.integer' => 'La quantité doit être un nombre entier.',
            'items.*.quantity.min' => 'La quantité doit être au moins 1.',
            'items.*.unit_price.required' => 'Le prix unitaire de l\'élément est obligatoire.',
            'items.*.unit_price.numeric' => 'Le prix unitaire doit être un nombre.',
            'items.*.unit_price.min' => 'Le prix unitaire doit être positif.',
        ];
    }
}