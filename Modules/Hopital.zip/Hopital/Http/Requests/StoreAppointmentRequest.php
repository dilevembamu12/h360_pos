<?php

namespace Modules\Hopital\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreAppointmentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // Autoriser si l'utilisateur est authentifié et potentiellement a la permission 'create appointment'.
        return auth()->check();
        // return auth()->user()->can('create appointment');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'patient_id' => 'required|exists:hopital_patients,id', // Le patient doit exister
            'doctor_id' => 'required|exists:hopital_staff,id', // Le médecin doit exister (ajustez la table si nécessaire)
            'start_time' => 'required|date', // Date et heure de début du RDV
            'end_time' => 'required|date|after:start_time', // Date et heure de fin, doit être après le début
            'appointment_type' => 'required|string|max:255', // Type de consultation (Ex: Consultation Générale, Spécialiste, Suivi)
            'status' => 'required|in:Scheduled,Completed,Cancelled,No-show', // Statut du RDV
            'notes' => 'nullable|string', // Notes additionnelles
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'patient_id.required' => 'Le patient est obligatoire pour le rendez-vous.',
            'patient_id.exists' => 'Le patient sélectionné n\'existe pas.',
            'doctor_id.required' => 'Le médecin est obligatoire pour le rendez-vous.',
            'doctor_id.exists' => 'Le médecin sélectionné n\'existe pas.',
            'start_time.required' => 'L\'heure de début du rendez-vous est obligatoire.',
            'start_time.date' => 'L\'heure de début doit être une date et heure valide.',
            'end_time.required' => 'L\'heure de fin du rendez-vous est obligatoire.',
            'end_time.date' => 'L\'heure de fin doit être une date et heure valide.',
            'end_time.after' => 'L\'heure de fin doit être après l\'heure de début.',
            'appointment_type.required' => 'Le type de consultation est obligatoire.',
            'status.required' => 'Le statut du rendez-vous est obligatoire.',
            'status.in' => 'Le statut du rendez-vous n\'est pas valide.',
        ];
    }
}