<?php

namespace Modules\Hopital\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdatePatientRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // Autoriser si l'utilisateur est authentifié et potentiellement a la permission 'update patient'.
        return auth()->check();
        // return auth()->user()->can('update patient');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        // Récupérer l'ID du patient depuis la route (ex: /patients/{patient})
        // Si votre route utilise un nom différent, ajustez 'patient'.
        $patientId = $this->route('patient');

        return [
            'first_name' => 'sometimes|required|string|max:255', // 'sometimes' pour que le champ ne soit pas toujours obligatoire
            'last_name' => 'sometimes|required|string|max:255',
            'date_of_birth' => 'sometimes|required|date',
            'gender' => 'sometimes|required|in:Male,Female,Other',
            'phone_number' => 'nullable|string|max:20',
            'address' => 'nullable|string|max:500',
            // L'email doit être unique SAUF pour le patient que l'on met à jour
            'email' => [
                'nullable',
                'email',
                Rule::unique('hopital_patients', 'email')->ignore($patientId),
            ],
            'blood_type' => 'nullable|string|max:5',
            'is_inpatient' => 'sometimes|required|boolean',
            // Ajoutez d'autres champs si nécessaire
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages()
    {
         return [
            'first_name.required' => 'Le prénom du patient est obligatoire.',
            'last_name.required' => 'Le nom du patient est obligatoire.',
            'date_of_birth.required' => 'La date de naissance est obligatoire.',
            'date_of_birth.date' => 'La date de naissance doit être une date valide.',
            'gender.required' => 'Le genre est obligatoire.',
            'gender.in' => 'Le genre doit être Homme, Femme ou Autre.',
            'email.unique' => 'Cet email est déjà utilisé par un autre patient.',
            'is_inpatient.required' => 'Le statut d\'hospitalisation (ambulatoire/hospitalisé) est obligatoire.',
            'is_inpatient.boolean' => 'Le statut d\'hospitalisation doit être un booléen.',
            // Les messages pour les champs avec 'sometimes|required' doivent mentionner
            // qu'ils sont requis S'ils sont présents dans la requête.
        ];
    }
}