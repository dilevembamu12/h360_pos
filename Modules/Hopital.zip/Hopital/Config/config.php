<?php

return [
    'name' => 'Hopital', // Le nom complet du module
    'alias' => 'hopital', // Un alias court et unique pour le module (utile pour les routes, vues, etc.)

    // Vous pourriez ajouter ici d'autres paramètres de configuration spécifiques
    // à votre module Hopital, si nécessaire. Par exemple :
    // 'default_currency' => 'XOF',
    // 'enable_emergency_alerts' => true,
];