<div class="row">
    <div class="col-xs-12">
        <h4>Revivez les tours guidés à tout moment.</h4>
        <p>Cliquez sur un tour pour le lancer.</p>
        <div id="usertour-onboarding-list-container">
            <div class="callout callout-warning">
                <p>
                    <i class="fas fa-exclamation-triangle"></i>
                    La liste des tours guidés disponibles apparaîtra ici. Connectez votre compte usertour.io.
                </p>
            </div>
        </div>
    </div>
</div>