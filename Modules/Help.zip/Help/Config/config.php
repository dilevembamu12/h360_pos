<?php

return [
    'name' => 'Help',
    'module_version' => '1.0',
];