<?php

namespace Modules\Help\Entities;

use Illuminate\Database\Eloquent\Model;

class OnboardingStep extends Model
{
    protected $guarded = ['id'];
}