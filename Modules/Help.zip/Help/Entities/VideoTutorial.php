<?php

namespace Modules\Help\Entities;

use Illuminate\Database\Eloquent\Model;

class VideoTutorial extends Model
{
    protected $guarded = ['id'];
}