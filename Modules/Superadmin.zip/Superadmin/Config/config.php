<?php

return [
    'name' => 'Superadmin',
    'module_version' => '4.0',
];
